#include "drink_machine_top.h"

NCSC_MODULE_EXPORT(drink_machine_top)
