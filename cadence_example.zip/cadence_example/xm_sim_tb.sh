#!/bin/sh --login

# ---------------------------------------------------------------------
#
# COPYRIGHT_DATE
# COPYRIGHT_COMPANY
#
# Please review the terms of the license agreement before using this
# file.  If you are not an authorized user, please destroy this source
# file and notify FhG IPMS immediately that you inadvertently 
# received an unauthorized copy.
# ---------------------------------------------------------------------
#
#  Project       : IPCORE_PROJECT
#
#  File          : xm_sim_lin_tb.sh
#  Dependencies  : none
#
#  Model Type:   : executable script
#
#  Description   : Compile script for Cadence Xcelium simulation 
#
#  Designer      : MZ
#
#  QA Engineer   : RH
#
#  Creation Date : 19-Dec-2016
#
#  Version       : IP_CORE_VERSION
# ---------------------------------------------------------------------

. ../../global_src/LOAD_EDA

# ---------------------------------------------------------------------
# rm -r -f ./xm_sim
# mkdir ./xm_sim
# rm -r -f ./waves.shm
# touch hdl.var
# ---------------------------------------------------------------------

echo '----------------------------------------------------------------'
echo ' Select Source or Netlist'
echo '----------------------------------------------------------------'
echo ' <1> Source code: SystemC'
echo '----------------------------------------------------------------'

#read sel
echo ' Start testbench...'
which xmsc_run
which xrun
#xmsc_run *.cpp -layout cdebug -top test_drink -scfrontend &


#rtl_ver="
#
#    ../../rtl/sdram_controller.v
#"
##    ../../rtl/sdram_controller.v    double_click
#tb_ver="
#	../../bench/sdram_controller_tb.v
#"
##	../../bench/sdram_controller_tb.v    double_click_tb
#xmvlog -work xm_sim -cdslib scripts/cds.lib -nolog -errormax 3 -update -linedebug $rtl_ver
#xmvlog -work xm_sim -cdslib scripts/cds.lib -nolog -errormax 3 -update -linedebug $tb_ver
#
#
#xmelab -work xm_sim -cdslib scripts/cds.lib -nolog -errormax 3 -access +wc -status  xm_sim.sdram_controller_tb:module &
#sleep 2
#
#xmsim  -gui         -cdslib scripts/cds.lib -nolog -messages -status -extassertmsg  xm_sim.sdram_controller_tb:module &
