#!/bin/sh --login

. ../../global_src/LOAD_EDA

if [ ! -f sdram_dpi_export.h ]; then
  echo "Generating SDRAM DPI headers"
  xrun -f gen_sdram_header.f
fi

xrun -f run_sdram.f -R -gui -access +rwc "$@"

