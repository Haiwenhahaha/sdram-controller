#!/bin/sh --login

# ---------------------------------------------------------------------
#
# COPYRIGHT_DATE
# COPYRIGHT_COMPANY
#
# Please review the terms of the license agreement before using this
# file.  If you are not an authorized user, please destroy this source
# file and notify FhG IPMS immediately that you inadvertently 
# received an unauthorized copy.
# ---------------------------------------------------------------------
#
#  Project       : IPCORE_PROJECT
#
#  File          : xm_sim_lin_tb.sh
#  Dependencies  : none
#
#  Model Type:   : executable script
#
#  Description   : Compile script for Cadence Xcelium simulation 
#
#  Designer      : MZ
#
#  QA Engineer   : RH
#
#  Creation Date : 19-Dec-2016
#
#  Version       : IP_CORE_VERSION
# ---------------------------------------------------------------------

. ../../../global_src/LOAD_EDA

# ---------------------------------------------------------------------
# rm -r -f ./xm_sim
# mkdir ./xm_sim
# rm -r -f ./waves.shm
# touch hdl.var
# ---------------------------------------------------------------------



#read sel
echo ' Start testbench...'
which xmsc_run
which xrun
#xmsc_run *.cpp -layout cdebug -top test_drink -scfrontend &

if [ ! -f sdram_dpi_export.h ]; then
  echo "Generating SDRAM DPI headers"
  xrun -f gen_sdram_header.f
    
fi
# Clean up temporary library after header generation
if [ -f sdram_dpi_export.h ] && [ -d tmp_xcelium.d ]; then
  rm -rf tmp_xcelium.d
fi

xrun -f run_sdram.f -gui -access +rwc "$@"
#xrun -f run_sdram.f -R -gui -access +rwc "$@"



