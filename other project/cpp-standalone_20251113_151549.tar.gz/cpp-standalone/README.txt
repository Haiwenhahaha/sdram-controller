cpp1 Packaging Overview
=======================

Mode: standalone
Timestamp: Do 13. Nov 15:15:49 CET 2025

Contents:
---------
- Vtoplevel: Executable
- Vtoplevel*.h: Header files
- Vtoplevel*.cpp: Source files
- Vtoplevel__ALL.a: Static library
- Vtoplevel.mk: Makefile
- Vtoplevel_classes.mk: Class definition Makefile
Note: This bundle contains the Verilator headers. You do not need a system-wide Verilator installation.\nThe Makefile has been updated to use the packaged headers.\n
Usage:
------
1. Extract the archive
2. Enter the extracted directory
3. Run the executable: ./Vtoplevel
4. Or rebuild: make -f Vtoplevel.mk

Requirements:
-------------
- C++ compiler (GCC/Clang)
- Standard C++ runtime libraries
- Verilator (Included in this package)

