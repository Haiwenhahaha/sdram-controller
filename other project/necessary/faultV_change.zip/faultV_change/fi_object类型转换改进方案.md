# fi_object 类型转换改进方案

## 问题背景

当前实现中，`fi_object<T>` 类只有一个 `operator QData()` 类型转换操作符。在某些场景下（如三元运算符），可能需要显式类型转换 `(IData)` 来避免编译错误。

本文档讨论可能的改进方案，以减少或消除对显式类型转换的需求。

## 当前实现

```cpp
template <typename T>
class fi_object : fi_object_base {
    // ...
    inline operator QData() const{ return m_value; }
    // ...
};
```

**问题**：当 `fi_object<IData>` 需要与 `unsigned int` 等类型进行比较或参与三元运算时，编译器可能无法自动找到转换路径。

## 改进方案

### 方案 A：添加更多类型转换操作符

**实现**：
```cpp
template <typename T>
class fi_object : fi_object_base {
    // ... 现有代码 ...
    
    // 添加更多类型转换操作符
    inline operator QData() const { return m_value; }
    inline operator IData() const { return static_cast<IData>(m_value); }
    inline operator SData() const { return static_cast<SData>(m_value); }
    inline operator CData() const { return static_cast<CData>(m_value); }
    inline operator unsigned int() const { return static_cast<unsigned int>(m_value); }
    inline operator int() const { return static_cast<int>(m_value); }
    // ...
};
```

**优点**：
- ✅ 编译器可以自动找到转换路径，不需要显式转换
- ✅ 更符合 C++ 最佳实践
- ✅ 减少代码生成时的特殊处理

**缺点**：
- ❌ 增加了 `fi_object` 类的复杂度
- ❌ 可能引入意外的隐式转换
- ❌ 需要为每种可能的类型添加转换操作符

**适用场景**：
- 当类型转换问题频繁出现时
- 当希望代码更简洁时

---

### 方案 B：使用模板特化

**实现**：
```cpp
template <typename T>
class fi_object : fi_object_base {
    // 通用实现
    inline operator QData() const { return m_value; }
    // ...
};

// 为 IData 特化
template <>
inline fi_object<IData>::operator IData() const { 
    return m_value;  // 直接返回，无需转换
}

// 为 CData 特化
template <>
inline fi_object<CData>::operator CData() const { 
    return m_value;
}
```

**优点**：
- ✅ 类型安全，避免不必要的转换
- ✅ 性能更好（直接返回，无需转换）
- ✅ 可以为每种类型定制转换逻辑

**缺点**：
- ❌ 实现复杂，需要为每种类型特化
- ❌ 代码重复，维护成本高
- ❌ 仍然需要为其他类型（如 `unsigned int`）添加转换

**适用场景**：
- 当需要为不同类型提供不同的转换逻辑时
- 当性能是关键考虑因素时

---

### 方案 C：通用模板转换操作符

**实现**：
```cpp
template <typename T>
class fi_object : fi_object_base {
    // ... 现有代码 ...
    
    // 通用模板转换操作符
    template<typename U>
    operator U() const { 
        return static_cast<U>(m_value); 
    }
    
    // 或者更安全的版本（只允许整数类型）
    template<typename U>
    typename std::enable_if<std::is_integral<U>::value, U>::type
    operator U() const { 
        return static_cast<U>(m_value); 
    }
};
```

**优点**：
- ✅ 一个操作符解决所有问题
- ✅ 自动支持所有整数类型转换
- ✅ 代码简洁，易于维护

**缺点**：
- ❌ 可能引入太多隐式转换，导致意外的类型转换
- ❌ 可能与其他类型发生冲突
- ❌ 需要仔细设计，避免过度转换

**适用场景**：
- 当需要支持多种类型转换时
- 当可以接受更多隐式转换时

---

### 方案 D：混合方案（推荐）

**实现**：
```cpp
template <typename T>
class fi_object : fi_object_base {
    // ... 现有代码 ...
    
    // 保留现有的 QData 转换（用于 Verilator 内部）
    inline operator QData() const { return m_value; }
    
    // 添加 Verilator 常用类型的转换
    inline operator IData() const { return static_cast<IData>(m_value); }
    inline operator SData() const { return static_cast<SData>(m_value); }
    inline operator CData() const { return static_cast<CData>(m_value); }
    
    // 添加常用整数类型转换
    inline operator unsigned int() const { return static_cast<unsigned int>(m_value); }
    inline operator int() const { return static_cast<int>(m_value); }
    
    // 保留 get_value() 方法作为显式获取值的方式
    inline T get_value() { return m_value; }
};
```

**优点**：
- ✅ 平衡了自动转换和类型安全
- ✅ 覆盖了 Verilator 常用的类型
- ✅ 仍然保留了显式获取值的方法
- ✅ 不会引入过多的隐式转换

**缺点**：
- ❌ 需要维护多个转换操作符
- ❌ 如果遇到新的类型，可能需要添加新的转换

**适用场景**：
- **推荐方案**：平衡了便利性和安全性
- 适合大多数使用场景

---

## 实施建议

### 当前阶段
- **保持当前方法（显式转换）**：
  - 简单可靠
  - 不会引入意外的副作用
  - 代码意图明确

### 如果遇到问题
如果编译时频繁出现类型转换错误，可以考虑：

1. **短期方案**：在 `fi_object` 类中添加 `operator IData()`、`operator unsigned int()` 等常用类型的转换操作符（方案 D）

2. **长期方案**：如果问题持续，可以考虑使用通用模板转换操作符（方案 C），但需要仔细测试，确保不会引入意外的转换

### 实施步骤（如果采用方案 D）

1. **修改 `V3EmitCModel.cpp`**：
   - 在 `fi_object` 类定义中添加类型转换操作符（约第325行之后）

2. **测试**：
   - 编译生成的代码，确保没有类型转换错误
   - 验证不会引入意外的隐式转换

3. **可选**：移除 `V3EmitCFunc.h` 中的显式类型转换（如果不再需要）

---

## 总结

| 方案 | 复杂度 | 类型安全 | 维护成本 | 推荐度 |
|------|--------|----------|----------|--------|
| 当前方法（显式转换） | 低 | 高 | 低 | ⭐⭐⭐⭐ |
| 方案 A（多个操作符） | 中 | 中 | 中 | ⭐⭐⭐ |
| 方案 B（模板特化） | 高 | 高 | 高 | ⭐⭐ |
| 方案 C（通用模板） | 低 | 低 | 低 | ⭐⭐ |
| 方案 D（混合方案） | 中 | 高 | 中 | ⭐⭐⭐⭐⭐ |

**建议**：先使用当前方法，如果遇到频繁的类型转换问题，再考虑实施方案 D。

