# Verilator 故障注入功能修改确认文档

## 文档说明

本文档记录了将 `verilator-fault_simulation` 的故障注入功能移植到 `verilator-master` 所需的所有代码修改。

**参考来源**：
- `verilator-fault_simulation`：基于旧版本 Verilator 的故障注入实现
- `verilator-master`：最新版本的 Verilator（代码结构已重构）

**注意**：由于版本差异，某些文件位置和代码结构发生了变化，本文档已重新确认所有修改位置。

---

## 修改概述

### 核心机理（简要说明）

故障注入功能通过以下机制实现：

1. **标记阶段**：在 AST 处理阶段，为需要注入故障的信号添加标记（`m_fi` 标志）
2. **类型替换**：在代码生成阶段，将普通信号类型（`CData`/`SData`/`IData`/`QData`）替换为 `fi_object<T>` 类型
3. **运算符拦截**：通过 C++ 运算符重载，在每次信号赋值时拦截并应用故障
4. **运行时控制**：通过静态成员变量控制故障注入的时间、位置和类型

**详细机理说明请参见 `故障注入机理说明.md` 文档。**

---

## 修改文件清单

修改文件：
- V3AstNodeOther.h  (注意：verilator-master 中对应的是 V3AstNodeOther.h，不是 V3AstNodes.h) 
- V3LinkLevel.cpp 
- V3Options.cpp 
- V3Options.h 
- V3EmitCBase.cpp （修改 emitVarDecl 函数）
- V3EmitCModel.cpp （添加头文件、fi_object 类定义、静态成员变量定义）
- V3EmitCFunc.h （添加类型转换）

ref:
https://github.com/verilator/verilator/pull/2724/commits/2c23fd7e36e4d0f724deda29b80e5defc643e57e#diff-2593cae5cd0fe27a6dec20c6477eedbec56537820caf1a58d3a65a43d9ceacd3





## V3AstNodeOther.h (verilator-master 中的对应文件)

**注意**：在 `verilator-fault_simulation` 中，`AstVar` 类定义在 `V3AstNodes.h` 中，但在 `verilator-master` 中，`AstVar` 类定义在 `V3AstNodeOther.h` 中。

### 修改位置 1: 添加成员变量

**文件**: `verilator-master/src/V3AstNodeOther.h`

**位置**: 在 `AstVar` 类的私有成员变量部分，`m_trace` 之后（第1916行）

**修改内容**:
```cpp
bool m_trace : 1;  // Trace this variable
bool m_fi : 1;     // Fault injection flag (fi)
bool m_isLatched : 1;  // Not assigned in all control paths of combo always
```

### 修改位置 2: 在 init() 函数中初始化

**位置**: 在 `AstVar::init()` 函数中，`m_trace = false;` 之后（第1969行）

**修改内容**:
```cpp
m_trace = false;
m_fi = false;  // Fault injection flag initialization (fi)
m_isLatched = false;
```

### 修改位置 3: 添加 setter 方法

**位置**: 在 `AstVar` 类的公共方法部分，`trace()` 方法附近（第2129行）

**修改内容**:
```cpp
void trace(bool flag) { m_trace = flag; }
void fi(bool flag) { m_fi = flag; }  // Fault injection setter (fi)
void isLatched(bool flag) { m_isLatched = flag; }
```

### 修改位置 4: 添加 getter 方法

**位置**: 在 `AstVar` 类的公共方法部分，`isTrace()` 方法之后（第2220行）

**修改内容**:
```cpp
bool isTrace() const { return m_trace; }
bool isFi() const { return m_fi; }  // Fault injection getter (fi)
bool isRand() const { return m_rand.isRand(); }
```

**参考**: verilator-fault_simulation/src/V3AstNodes.h
- 第1952行: `bool m_fi:1; //fi` - 成员变量声明
- 第1992行: `m_fi = false; //fi` - init() 函数中初始化
- 第2118行: `void fi(bool flag) { m_fi = flag; } //fi` - setter 方法
- 第2190行: `bool isFi() const { return m_fi; }//fi` - getter 方法








## V3LinkLevel.cpp

### 修改位置: 在 wrapTopCell() 函数中添加故障注入标记

**文件**: `verilator-master/src/V3LinkLevel.cpp`

**位置**: 在 `wrapTopCell()` 函数中，约第298-300行（在检查 `isRef()` 之后，`systemC()` 检查之前）

**修改内容**:
```cpp
if (varp->isRef() || varp->isConstRef()) {
    varp->v3warn(E_UNSUPPORTED,
                 "Unsupported: ref/const ref as primary input/output: "
                     << varp->prettyNameQ());
}
if (v3Global.opt.fault_injection()) {  // fi
    varp->fi(true);
}
if (varp->isIO() && v3Global.opt.systemC()) {
    varp->sc(true);
    // ...
}
```

### 代码解释

#### 1. 代码上下文

这段代码位于 `V3LinkLevel::wrapTopCell()` 函数中，该函数的作用是：
- **创建顶层包装模块**：为原始顶层模块创建一个新的包装模块（`$root`）
- **提升 IO 端口**：将原始顶层模块的 IO 端口提升到新的包装模块中
- **创建连接**：通过 `AstPin` 连接新模块的端口和原始模块的端口

#### 2. 代码位置和作用

**位置**：在创建新的 `varp`（从原始模块的 `oldvarp` 克隆而来）并设置其属性之后：

```cpp
// 1. 克隆原始变量
AstVar* const varp = oldvarp->cloneTree(false);

// 2. 设置变量属性
varp->name(name);
varp->protect(false);
newmodp->addStmtsp(varp);
varp->sigPublic(true);
oldvarp->primaryIO(false);
varp->primaryIO(true);

// 3. 检查 ref/const ref（不支持）
if (varp->isRef() || varp->isConstRef()) {
    varp->v3warn(E_UNSUPPORTED, ...);
}

// 4. 【故障注入标记】如果启用了故障注入，标记该变量
if (v3Global.opt.fault_injection()) {  // fi
    varp->fi(true);  // 设置故障注入标志
}

// 5. 其他属性设置（SystemC、trace 等）
if (varp->isIO() && v3Global.opt.systemC()) {
    varp->sc(true);
    // ...
}
```

#### 3. 代码功能详解

**`if (v3Global.opt.fault_injection())`**：
- **检查条件**：判断用户是否在命令行中使用了 `-fi` 选项启用了故障注入功能
- **`v3Global.opt.fault_injection()`**：返回 `true` 表示启用了故障注入，`false` 表示未启用

**`varp->fi(true)`**：
- **作用**：将变量 `varp` 的故障注入标志 `m_fi` 设置为 `true`
- **意义**：标记该变量为**可注入故障的目标**
- **后续影响**：在 `V3EmitC.cpp` 中生成代码时，会检查 `varp->isFi()` 来决定是否将该变量声明为 `fi_object<type>` 类型

#### 4. 为什么在这里添加？

**时机选择**：
- ✅ **在变量创建之后**：此时 `varp` 已经创建并添加到新模块中
- ✅ **在属性设置之后**：`primaryIO(true)` 等属性已设置，变量已准备好
- ✅ **在 IO 端口提升过程中**：确保所有提升到顶层的 IO 端口都被标记

**作用范围**：
- 只标记**提升到顶层包装模块的 IO 端口**
- 这些端口是用户可以访问和注入故障的主要目标
- 内部信号会在 `V3EmitC.cpp` 中根据其他条件处理

#### 5. 与其他修改的关系

- **V3AstNodeOther.h**：定义了 `m_fi` 成员变量和 `fi()`、`isFi()` 方法
- **V3LinkLevel.cpp**（这里）：在变量创建时设置 `fi(true)` 标志
- **V3EmitCBase.cpp**：在生成代码时检查 `isFi()`，决定是否使用 `fi_object<type>`

**详细工作流程请参见 `故障注入机理说明.md`。**

**参考**: verilator-fault_simulation/src/V3LinkLevel.cpp
- 第229-231行: `if (v3Global.opt.fault_injection()) { varp->fi(true); }`


## V3Options.cpp

### 修改位置: 添加 `-fi` 命令行选项解析

**文件**: `verilator-master/src/V3Options.cpp`

**位置**: 在 `parseOptsList()` 函数中，第1325行（在 `-cc` 选项之后）

**修改内容**:
```cpp
DECL_OPTION("-cc", CbCall, [this]() { ccSet(); });
DECL_OPTION("-fi", CbCall, [this]() { m_fault_injection = true; });  // Fault injection
DECL_OPTION("-clk", CbVal, [fl](const std::string&) {
    // ...
});
```

### 代码解释

#### 1. 选项解析系统

**新版本 Verilator 使用 `DECL_OPTION` 宏系统**：
- `verilator-fault_simulation` 使用旧的字符串比较方式（`strcmp`）
- `verilator-master` 使用新的 `V3OptionParser` 系统
- 新系统更灵活，支持自动补全和错误提示

#### 2. `-fi` 选项定义

**`DECL_OPTION("-fi", CbCall, [this]() { m_fault_injection = true; })`**：
- **`"-fi"`**：命令行选项名称，用户使用 `verilator -fi design.v` 来启用故障注入
- **`CbCall`**：回调类型，表示这是一个无参数的选项（类似 `-cc`、`-sc`）
- **`[this]() { m_fault_injection = true; }`**：Lambda 函数，当解析到 `-fi` 选项时执行
  - 将 `m_fault_injection` 成员变量设置为 `true`
  - 表示用户启用了故障注入功能

#### 3. 与其他修改的关系

- **V3Options.h**：定义了 `m_fault_injection` 成员变量和 `fault_injection()` 访问器
- **V3LinkLevel.cpp**：通过 `v3Global.opt.fault_injection()` 检查是否启用故障注入
- **V3EmitCBase.cpp**：通过 `v3Global.opt.fault_injection()` 决定是否生成 `fi_object<T>` 类型

**详细工作流程请参见 `故障注入机理说明.md`。**



**参考**: verilator-fault_simulation/src/V3Options.cpp
- 第988-989行: `} else if ( !strcmp (sw, "-fi") ) { m_fault_injection = true; }`
- **注意**：旧版本使用字符串比较，新版本使用 `DECL_OPTION` 系统

## V3Options.h

### 修改位置 1: 添加成员变量

**文件**: `verilator-master/src/V3Options.h`

**位置**: 在 `V3Options` 类的私有成员变量部分，第312行（`m_xInitialEdge` 之后）

**修改内容**:
```cpp
bool m_xInitialEdge = false;    // main switch: --x-initial-edge
bool m_fault_injection = false;  // main switch: -fi (fault injection)
```

### 修改位置 2: 添加访问器方法

**位置**: 在 `V3Options` 类的公共访问器方法部分，第589行（`xInitialEdge()` 之后）

**修改内容**:
```cpp
bool xInitialEdge() const { return m_xInitialEdge; }
bool fault_injection() const { return m_fault_injection; }  // Fault injection flag accessor
```

### 代码解释

#### 1. 成员变量 `m_fault_injection`

**`bool m_fault_injection = false;`**：
- **类型**：`bool`，布尔值，表示故障注入功能是否启用
- **默认值**：`false`，默认不启用故障注入
- **作用**：存储用户是否在命令行中使用了 `-fi` 选项
- **命名**：使用下划线分隔（`m_fault_injection`），遵循 Verilator 的命名约定

#### 2. 访问器方法 `fault_injection()`

**`bool fault_injection() const { return m_fault_injection; }`**：
- **返回类型**：`bool`，返回故障注入标志的状态
- **`const`**：方法不修改对象状态，只读取
- **作用**：提供对私有成员变量的只读访问
- **使用场景**：
  ```cpp
  if (v3Global.opt.fault_injection()) {
      // 启用故障注入相关功能
      varp->fi(true);
  }
  ```

#### 3. 与其他成员变量的关系

- **`m_systemC`**：SystemC 输出格式标志
- **`m_trace`**：波形跟踪标志
- **`m_vpi`**：VPI 接口标志
- **`m_fault_injection`**：故障注入标志（新增）

#### 4. 访问模式

**Verilator 的选项访问模式**：
- 成员变量：`m_xxx`（私有，类内部使用）
- 访问器：`xxx()`（公共，外部代码使用）
- 全局访问：`v3Global.opt.xxx()`（通过全局对象访问）

**参考**: verilator-fault_simulation/src/V3Options.h
- 第323行: `bool m_fault_injection = false; //fi` - 成员变量声明
- 第445行: `bool fault_injection() const { return m_fault_injection; }//fi` - 访问器方法


## V3EmitC 相关文件修改

### 文件映射说明

**注意**：在 `verilator-fault_simulation` 中，所有代码生成逻辑都在 `V3EmitC.cpp` 中。但在新版本的 `verilator-master` 中，代码生成被拆分成了多个模块化文件：

- **`V3EmitC.h`** / **`V3EmitCBase.h`**：头文件，声明代码生成相关的类和函数
- **`V3EmitCBase.cpp`**：基础代码生成，包括变量声明、类型转换等
- **`V3EmitCClass.cpp`**：类成员变量和方法的生成
- **`V3EmitCModel.cpp`**：模型相关代码生成（头文件、类定义、静态成员变量定义等）
- **`V3EmitCFunc.cpp`** / **`V3EmitCFunc.h`**：函数体代码生成（包括表达式、条件语句等）
- **`V3EmitCMain.cpp`**：主函数生成
- **`V3EmitCInlines.cpp`**：内联函数生成

**参考**: verilator-fault_simulation/src/V3EmitC.cpp
### 实际修改的文件列表
5. **`V3EmitCBase.cpp`** ✅
   - 第23行：添加 `#include <deque>`（用于支持间歇性故障时间数组）
   - 第200-219行：修改 IO 信号声明为 `fi_object<T>` 类型
   - 第234-280行：修改内部信号声明为 `fi_object<T>` 类型（排除局部变量）

6. **`V3EmitCModel.cpp`** ✅
   - 第75-85行：在 `emitHeader()` 函数中添加故障注入所需的头文件包含
   - 第94-400行：在 `emitHeader()` 函数中添加 `fi_object_base` 和 `fi_object<T>` 类定义
   - 第872-884行：在 `emitImplementation()` 函数中添加静态成员变量定义

7. **`V3EmitCFunc.h`** ✅
   - 第1477-1481行：在 `visit(AstCond* nodep)` 函数中添加 `(IData)` 类型转换
   - 用于解决三元运算符中 `fi_object` 与 `unsigned int` 类型不匹配的问题



### 修改 1: 版本声明和头文件包含

**对应文件**: `verilator-master/src/V3EmitCBase.cpp` 或 `V3EmitCBase.h`

**参考位置**: verilator-fault_simulation/src/V3EmitC.cpp
- 第15-23行: 版本出处声明（版权信息）
- 第42行: `#include <deque> //fi`

**代码解释**:
- **版本声明**：添加了 Infineon Technologies AG 的修改版权声明
- **`#include <deque>`**：包含 `std::deque` 容器，用于存储间歇性故障（intermittent fault）的时间数组
  - `std::deque` 支持高效的 `pop_front()` 操作，适合管理故障注入和释放时间序列
  - 用于 `fi_object_base::if_inject_time` 和 `fi_object_base::if_release_time`

**在 verilator-master 中的位置**：
- ✅ **已修改**: 
  - `V3EmitCBase.cpp` 第23行：在源代码文件头部添加 `#include <deque>`（用于支持故障注入功能）
  - `V3EmitCModel.cpp` 第75-85行：在 `emitHeader()` 函数中添加故障注入所需的头文件包含（生成到输出文件中）

### 修改 2: 类型转换（fi_object 到 IData）

**在 verilator-master 中的位置**：
- ✅ **已修改**: `V3EmitCFunc.h` 第1477-1481行，在 `visit(AstCond* nodep)` 函数中添加类型转换
- 位置：在 `putbs(" ? ");` 之后，`iterateAndNextConstNull(nodep->thenp());` 之前

**参考位置**: verilator-fault_simulation/src/V3EmitC.cpp 第1001-1006行

**代码内容**:
```cpp
//Since there could be a comparison to unsigned int, convert fi_object to IData to fix compiler errors. Is there a better way?
if (v3Global.opt.fault_injection()){//fi
    if (!nodep->isQuad()) {
        puts("(IData)");
    } 
}
```

**代码解释**:

#### 1. 问题背景

**为什么需要这个类型转换？**

当 `fi_object<T>` 类型用于三元运算符（条件表达式）时，可能会遇到类型匹配问题：

```cpp
// 生成的代码可能是这样的：
fi_object<IData> signal_a;
unsigned int value = 100;

// 三元运算符：condition ? signal_a : value
// 或者：condition ? value : signal_a
```

**问题**：
- `fi_object<T>` 类只有一个 `operator QData()` 类型转换操作符（第325行）
- 当 `fi_object<IData>` 需要与 `unsigned int` 进行比较或参与三元运算时，C++ 编译器可能无法自动找到合适的转换路径
- 虽然 `fi_object<IData>` → `QData` → `IData` 在逻辑上是可行的，但编译器可能无法自动推断这个转换链

#### 2. 具体场景

**三元运算符的类型要求**：
```cpp
// C++ 要求三元运算符的两个分支类型必须兼容
condition ? expr1 : expr2
// expr1 和 expr2 必须可以转换为同一类型
```

**示例问题代码**：
```cpp
// 假设生成的代码是：
fi_object<IData> internal_reg;
unsigned int threshold = 10;

// 这行代码可能编译失败：
unsigned int result = (some_condition) ? internal_reg : threshold;
// 错误：无法在 fi_object<IData> 和 unsigned int 之间进行类型转换
```

**解决方案**：
```cpp
// 添加显式类型转换：
unsigned int result = (some_condition) ? (IData)internal_reg : threshold;
// 现在可以编译：fi_object<IData> → operator QData() → (IData) → unsigned int
```

#### 3. 为什么只在非 64 位时添加？

- **64 位（`isQuad()`）**：`fi_object<QData>` 已经有 `operator QData()`，可以直接转换
- **32 位及以下**：`fi_object<IData>`、`fi_object<SData>`、`fi_object<CData>` 需要先转换为 `QData`，再转换为目标类型，编译器可能无法自动推断

#### 4. 当前方法的优缺点

**优点**：
- ✅ 简单直接，明确告诉编译器类型转换
- ✅ 不需要修改 `fi_object` 类定义
- ✅ 只在确实需要的地方添加转换（三元运算符）
- ✅ 不会引入意外的隐式转换
- ✅ 代码意图明确，易于维护

**缺点**：
- ❌ 需要在每个可能出问题的地方添加转换
- ❌ 代码生成时需要在特定位置插入转换

**注意**：如果后续遇到更多类型转换相关的编译错误，可以考虑在 `fi_object` 类中添加更多的类型转换操作符（参见 `fi_object类型转换改进方案.md`）。



### 修改 3: IO 信号声明为 fi_object 类型

**在 verilator-master 中的位置**：
- ✅ **已修改**: `V3EmitCBase.cpp` 第200-219行，在 `emitVarDecl()` 函数中添加 IO 信号的 `fi_object<T>` 类型声明
- 位置：在 `else if (nodep->isIO() && basicp && !basicp->isOpaque())` 之前添加新的条件分支

**参考位置**: verilator-fault_simulation/src/V3EmitC.cpp 第1915-1925行

**代码内容**:
```cpp
} else if (nodep->isIO() && v3Global.opt.fault_injection() && !nodep->isWide() ) {//fi
    m_ctorVarsVec.push_back(nodep);
    if (nodep->isQuad()) puts("fi_object<QData> ");
    else if (nodep->widthMin() <= 8) puts("fi_object<CData> ");
    else if (nodep->widthMin() <= 16) puts("fi_object<SData> ");
    else puts("fi_object<IData> ");
    puts(nodep->name());
    puts(";\n");
    emitDeclArrayBrackets(nodep);
```

**代码解释**:
- **功能**：将 IO 端口信号声明为 `fi_object<T>` 类型，而不是普通的 `CData`/`SData`/`IData`/`QData`
- **条件**：
  - `nodep->isIO()`：必须是 IO 端口
  - `v3Global.opt.fault_injection()`：启用了故障注入
  - `!nodep->isWide()`：不是宽信号（数组），只处理标量或小数组
- **类型选择**：
  - `QData`：64 位（`isQuad()`）
  - `CData`：8 位（`widthMin() <= 8`）
  - `SData`：16 位（`widthMin() <= 16`）
  - `IData`：32 位（其他情况）
- **`m_ctorVarsVec.push_back(nodep)`**：将变量添加到构造函数变量列表，用于后续初始化
- **`emitDeclArrayBrackets(nodep)`**：生成数组维度声明（如 `[7:0]`）


### 修改 4: 内部信号声明为 fi_object 类型（排除局部变量）

**在 verilator-master 中的位置**：
- ✅ **已修改**: `V3EmitCBase.cpp` 第234-280行，在 `emitVarDecl()` 函数的 `else` 分支中添加内部信号的 `fi_object<T>` 类型声明
- 位置：在原有的 `else` 分支之前添加 `else if (v3Global.opt.fault_injection())` 分支

**参考位置**: verilator-fault_simulation/src/V3EmitC.cpp 第1954-1990行

**代码内容**:
```cpp
} else if (v3Global.opt.fault_injection()) {//fi
    std::string av_name = nodep->name();
    std::string last_char = nodep->vlArgType(true, false, false, prefixIfImp);
    std::string av_name_prefix = av_name.substr(0,11);
    std::string av_name_prefix2 = av_name.substr(0,12);
    std::string av_name_prefix3 = av_name.substr(0,7);
    std::string av_name_prefix4 = av_name.substr(0,6);
    bool local_variable = (av_name_prefix == "__VinpClk__" ||
                          av_name_prefix2 == "__Vclklast__" ||
                          av_name_prefix2 == "__Vchglast__" ||
                          av_name == "__Vm_traceActivity" ||
                          av_name_prefix3 == "__Vtemp" ||
                          av_name_prefix4 == "__Vdly" ||
                          av_name_prefix4 == "__Vilp");

    if (v3Global.opt.fault_injection() && !local_variable && !nodep->isWide() 
        && last_char.substr(last_char.length()-1) != "]" ) {
        m_ctorVarsVec.push_back(nodep);
        if (nodep->widthMin() <= 8) {
            puts("fi_object<CData> ");
        } else if (nodep->widthMin() <= 16) {
            puts("fi_object<SData> ");
        } else if (nodep->isQuad()) {
            puts("fi_object<QData> ");
        } else {
            puts("fi_object<IData> ");
        }
        puts(nodep->nameProtect());
    } else {
        puts(nodep->vlArgType(true, false, false, prefixIfImp));
        puts(";\n");
    }
    if (v3Global.opt.fault_injection() && !local_variable && !nodep->isWide()) {
        puts(";\n");
    }
}
```

**代码解释**:
- **功能**：将内部信号（非 IO）声明为 `fi_object<T>` 类型，但排除 Verilator 生成的临时变量
- **局部变量过滤**：排除以下 Verilator 内部生成的变量：
  - `__VinpClk__*`：时钟输入相关
  - `__Vclklast__*`：上一时钟周期值
  - `__Vchglast__*`：变化检测相关
  - `__Vm_traceActivity`：跟踪活动标志
  - `__Vtemp*`：临时变量
  - `__Vdly*`：延迟变量
  - `__Vilp*`：内部变量
- **条件检查**：
  - `!local_variable`：不是局部/临时变量
  - `!nodep->isWide()`：不是宽信号
  - `last_char != "]"`：避免多维数组（简化处理）
- **类型选择**：与 IO 信号相同，根据位宽选择 `CData`/`SData`/`IData`/`QData`
- **`nameProtect()`**：使用受保护的名称（处理 C++ 关键字冲突）



### 修改 5: fi_object_base 静态成员变量定义

**在 verilator-master 中的位置**：
- ✅ **已修改**: `V3EmitCModel.cpp` 第872-884行，在 `emitImplementation()` 函数中添加静态成员变量定义
- 位置：在 `#include` 语句之后，函数体开始处
**参考位置**: verilator-fault_simulation/src/V3EmitC.cpp 第2800-2813行

**代码内容**:
```cpp
if (v3Global.opt.fault_injection()){ //fi
    puts("fi_object_base::ffs_keys_t fi_object_base::ffs_keys;\n");
    puts("unsigned int fi_object_base::counter = 0;\n");
    puts("QData fi_object_base::injection_time = 0;\n");
    puts("QData fi_object_base::release_time = 0;\n");
    puts("std::string fi_object_base::injection_location = \"\";\n");
    puts("std::string fi_object_base::fault_type = \"\";\n");
    puts("unsigned int fi_object_base::mask = 0;\n");
    puts("bool fi_object_base::bit_vector = {};\n");
    puts("std::deque<QData> fi_object_base::if_release_time = {0};\n");
    puts("std::deque<QData> fi_object_base::if_inject_time = {0};\n");
}
```

**代码解释**:

#### 1. 为什么放在 `emitImplementation()` 函数中？

**C++ 静态成员变量规则**：
- **声明**：在类定义中（`emitHeader()` 生成的头文件中）
- **定义**：在实现文件中（`emitImplementation()` 生成的 `.cpp` 文件中）
- 如果定义在头文件中，会导致重复定义错误

**详细说明请参见 `故障注入机理说明.md` 的"静态成员变量设计"章节。**

#### 2. 这段代码的作用

**功能**：为 `fi_object_base` 类的静态成员变量分配存储空间并初始化

**静态成员变量说明**：
- **`ffs_keys`**：故障注入目标信号名称列表（`std::vector<std::string>`）
  - 用于存储所有可注入故障的信号名称
- **`counter`**：故障注入计数器
  - 用于统计已注册的故障注入目标数量
- **`injection_time`**：故障注入开始时间（`QData` = 64 位）
  - 指定何时开始注入故障
- **`release_time`**：故障释放时间
  - 指定何时停止注入故障
- **`injection_location`**：故障注入位置（信号名称）
  - 指定要注入故障的目标信号名称
- **`fault_type`**：故障类型字符串
  - 可选值："sa0", "sa1", "bit_flip", "intermittent_sa0", "intermittent_sa1", "intermittent_bf"
- **`mask`**：位掩码（用于部分位故障注入）
  - 用于指定哪些位需要注入故障
- **`bit_vector`**：是否使用位向量模式
  - `true`：使用 `mask` 进行部分位故障注入
  - `false`：对整个信号进行故障注入
- **`if_inject_time`**：间歇性故障注入时间数组（`std::deque<QData>`）
  - 存储多个间歇性故障的注入时间
- **`if_release_time`**：间歇性故障释放时间数组
  - 存储多个间歇性故障的释放时间

**初始化**：
- 所有变量都有默认初始值（0 或空字符串）
- 这些值在运行时会被用户配置覆盖

**注意**：这些静态成员变量在 `emitHeader()` 中已声明（类定义中），这里只是定义（分配存储空间）。





### 修改 6: 条件编译和头文件包含

**在 verilator-master 中的位置**：
- ✅ **已修改**: `V3EmitCModel.cpp` 第75-85行，在 `emitHeader()` 函数中添加故障注入所需的头文件
- 位置：与其他 `#include` 语句一起，在类声明之前
**参考位置**: verilator-fault_simulation/src/V3EmitC.cpp
- 第3070行: `if (!v3Global.opt.fault_injection()){//fi`
- 第3088行: ` }`
- 第3162-3173行: 头文件包含

**代码内容**:
```cpp
// 第3070行附近：条件编译（某些代码仅在非故障注入模式下生成）
if (!v3Global.opt.fault_injection()){//fi
    // ... 正常代码生成 ...
}

// 第3162-3173行：故障注入所需的头文件
if (v3Global.opt.fault_injection()) { //fi
    puts("#include <map>\n");
    puts("#include <string>\n");
    puts("#include <fstream>\n");
    puts("#include <sstream>\n");
    puts("#include <vector>\n");
    puts("#include <deque>\n");
    puts("#include <cstdlib>\n");
    puts("#include <ctime>\n");
    puts("\n");
}
```

**代码解释**:

#### 1. 原始代码中的条件编译（verilator-fault_simulation）

**第3070行的条件编译**：
```cpp
if (!v3Global.opt.fault_injection()){//fi
    // 生成匿名结构体代码（用于解决编译器成员计数bug）
    // ...
}
```

**作用**：
- 在故障注入模式下，跳过匿名结构体的生成
- 可能是为了避免与 `fi_object` 类型声明产生冲突
- 或者是为了简化故障注入模式下的代码生成

#### 2. 为什么现在不需要这个条件编译？

**原因**：
1. **Verilator 代码重构**：
   - 在 `verilator-master` 中，匿名结构体的生成代码可能已经被重构或移除
   - 代码结构发生了变化，不再需要这个条件编译

2. **头文件包含不影响正常代码生成**：
   - 我们添加的头文件（`<map>`, `<string>`, `<vector>` 等）都是 **C++ 标准库**
   - 这些头文件：
     - ✅ 只在启用故障注入时才包含（条件编译：`if (v3Global.opt.fault_injection())`）
     - ✅ 即使包含了也不会影响正常代码生成
     - ✅ 只是会增加一点点编译时间（影响很小，可以忽略）
     - ✅ 不会产生任何副作用或冲突

3. **条件编译仍然存在**：
   - 头文件包含本身就有条件编译保护
   - 只有在启用故障注入时才会包含这些头文件
   - 正常模式下不会包含，所以不影响正常代码生成

#### 3. 头文件说明

**包含的头文件及其用途**：
- **`<map>`**：映射结构（虽然代码中注释掉了，但保留以备将来使用）
- **`<string>`**：字符串操作（用于信号名称、故障类型等）
- **`<fstream>`**：文件 I/O（可能用于故障配置文件的读取）
- **`<sstream>`**：字符串流操作（用于字符串转换）
- **`<vector>`**：用于 `ffs_keys_t`（信号名称列表）
- **`<deque>`**：用于间歇性故障时间数组（支持高效的 `pop_front()` 操作）
- **`<cstdlib>`**：标准库函数（如 `rand()` 等）
- **`<ctime>`**：时间相关函数


### 修改 7: fi_object 类定义（核心故障注入类）

**对应文件**: `verilator-master/src/V3EmitCBase.cpp`
**在 verilator-master 中的位置**：
- ✅ **已修改**: `V3EmitCModel.cpp` 第94-400行（约），在 `emitHeader()` 函数中添加 `fi_object` 类定义
- 位置：在类前向声明之后，主类定义之前
- 这是整个故障注入机制的基础，所有 `fi_object<T>` 类型的信号都依赖这个类

**参考位置**: verilator-fault_simulation/src/V3EmitC.cpp 第3176-3439行

**代码内容**:
```cpp
if (v3Global.opt.fault_injection()){ //fi
    // fi_object_base 类定义
    // fi_object<T> 模板类定义
    // operator= 重载（故障注入逻辑）
    // 类型转换操作符
    // ...
}
```

**代码解释**:

这是故障注入功能的核心类定义，包含两个类：

#### 1. `fi_object_base` 基类

**功能**：提供故障注入的全局控制和状态管理

**主要成员**：
- **`ffs_keys_t`**：类型别名，`std::vector<std::string>`，存储可注入信号名称列表
- **`add()` 方法**：将信号添加到可注入目标列表
- **静态成员变量**（在修改5中定义）：
  - `ffs_keys`：信号名称列表
  - `counter`：计数器
  - `injection_time` / `release_time`：故障注入/释放时间
  - `injection_location`：目标信号名称
  - `fault_type`：故障类型字符串
  - `mask` / `bit_vector`：位掩码相关
  - `if_inject_time` / `if_release_time`：间歇性故障时间数组

#### 2. `fi_object<T>` 模板类

**功能**：包装硬件信号，通过运算符重载实现故障注入

**关键特性**：
- **构造函数**：接收信号名称，初始化值为 `T()`
- **`operator=` 重载**：核心故障注入逻辑
  - 检查当前信号是否为注入目标（`m_name == injection_location`）
  - 根据 `fault_type` 执行不同的故障注入（sa0, sa1, bit_flip, intermittent_*）
  - 时间控制：根据 `VL_TIME_Q()` 和 `injection_time`/`release_time` 决定是否注入
  - 位向量支持：通过 `mask` 实现部分位故障注入
- **类型转换操作符**：
  - `operator QData()`：转换为 64 位整数
  - `c_str()`：转换为 `unsigned char`
  - `get_value()`：获取实际值

**详细故障注入逻辑请参见 `故障注入机理说明.md` 的"故障类型实现"章节。**


puts("			if (fi_object_base::injection_time!=0 && fi_object_base::release_time!=0 ){\n");
puts("					static bool runOnce= true;\n");
puts("				if (VL_TIME_Q()>=fi_object_base::injection_time && VL_TIME_Q()<fi_object_base::release_time){\n");
puts("                              if (fi_object_base::bit_vector==true)      \n  ");
puts("                                  m_value=a & fi_object_base::mask; \n ");
puts("                              else  \n  ");
puts("					m_value=0;\n");
puts("					if (runOnce==true){\n");
puts("						std::cout<< \"Injecting stuck-at-0 fault at signal\" <<m_name<< \" during [\" <<fi_object_base::injection_time<<\",\" <<fi_object_base::release_time<<\"]\" ;\n");
puts("						runOnce=false;}\n");
puts("                                   }\n");
puts("					else\n");
puts("						m_value=a;\n");
puts("				 }\n");
puts("			if(fi_object_base::injection_time!=0 && fi_object_base::release_time==0){ \n"); 
puts("					static bool runOnce= true;\n");
puts("				if (VL_TIME_Q()>=fi_object_base::injection_time){\n");
puts("                              if (fi_object_base::bit_vector==true)    \n    ");
puts("                                  m_value=a & fi_object_base::mask; \n ");
puts("                              else   \n ");
puts("					m_value=0;\n");
puts("					if (runOnce==true){\n");
puts("						std::cout<< \"Injecting stuck-at-0 fault at signal \" <<m_name<< \" starting from time :\" << fi_object_base::injection_time;\n");
puts("					runOnce=false;}\n");
puts("					}\n");
puts("					else\n");
puts("					     m_value=a;\n");
puts("                            }\n");
puts("			if(fi_object_base::injection_time==0 && fi_object_base::release_time!=0 ){\n");
puts("					static bool runOnce= true;\n");
puts("				if (VL_TIME_Q()<fi_object_base::release_time){\n");
puts("                              if (fi_object_base::bit_vector==true)     \n   ");
puts("                                  m_value=a & fi_object_base::mask; \n ");
puts("                              else   \n ");
puts("					m_value=0;\n");
puts("					if (runOnce==true){\n");
puts("						std::cout<< \"Injecting stuck-at-0 fault at signal \" <<m_name<< \" until time:\" << fi_object_base::release_time-1;\n");
puts("						runOnce=false;}\n");
puts("					 }\n");
puts("					else\n");
puts("						m_value=a;\n");
puts("				}\n");
puts("			if(fi_object_base::injection_time==0 && fi_object_base::release_time==0 ){\n");
puts("                              if (fi_object_base::bit_vector==true)      \n  ");
puts("                                  m_value=a & fi_object_base::mask; \n ");
puts("                              else   \n ");
puts("				m_value=0;\n");
puts("				static bool runOnce= true;\n");
puts("				if (runOnce==true){\n");
puts("					std::cout<< \"The signal \" <<m_name<< \" is permanently stuck to 0\";\n");
puts("					runOnce=false;}\n");
puts("				}\n");
puts("			}\n");
puts("		else if (fi_object_base::fault_type==\"sa1\"){\n");
puts("			if (fi_object_base::injection_time!=0  && fi_object_base::release_time!=0  ){\n");
puts("					static bool runOnce= true;\n");
puts("				if (VL_TIME_Q()>=fi_object_base::injection_time && VL_TIME_Q()<fi_object_base::release_time){\n");
puts("                              if (fi_object_base::bit_vector==true)     \n   ");
puts("                                  m_value=a | fi_object_base::mask; \n ");
puts("                              else  \n  ");
puts("					m_value=1;\n");
puts("					if (runOnce==true){\n");
puts("						std::cout<< \"Injecting stuck-at-1 fault at signal \" <<m_name<< \" during [\" <<fi_object_base::injection_time<< \",\" <<fi_object_base::release_time<<\"]\" ;\n");
puts("						runOnce=false;}\n");
puts("					}\n");
puts("					else\n");
puts("						m_value=a;\n");
puts("				}\n");
puts(" 			if(fi_object_base::injection_time!=0 && fi_object_base::release_time==0  ){ \n"); 
puts("					static bool runOnce= true;\n");
puts("				if (VL_TIME_Q()>=fi_object_base::injection_time){\n");
puts("                              if (fi_object_base::bit_vector==true)   \n     ");
puts("                                  m_value=a | fi_object_base::mask; \n ");
puts("                              else   \n ");
puts("					m_value=1;\n");
puts("					static bool runOnce= true;\n");
puts("					if (runOnce==true){\n");
puts("						std::cout<< \"Injecting stuck-at-1 fault at signal \" <<m_name<< \" starting from time :\" << fi_object_base::injection_time;\n");
puts("						runOnce=false;}\n");
puts("					}\n");
puts("					else \n");
puts("						m_value=a;\n");
puts("				}\n");
puts("			if(fi_object_base::injection_time==0 && fi_object_base::release_time!=0  ){\n");
puts("					static bool runOnce= true;\n");
puts("				if (VL_TIME_Q()<fi_object_base::release_time){\n");
puts("                              if (fi_object_base::bit_vector==true)   \n     ");
puts("                                  m_value=a | fi_object_base::mask; \n ");
puts("                              else  \n  ");
puts("					m_value=1;\n");
puts("					if (runOnce==true){\n");
puts("						std::cout<< \"Injecting stuck-at-1 fault at signal \" <<m_name<< \" until time: \" << fi_object_base::release_time;\n");
puts("						runOnce=false;}\n");
puts("					}\n");
puts("					else \n");
puts("						m_value=a;\n");
puts("				}\n");
puts("			if(fi_object_base::injection_time==0 && fi_object_base::release_time==0  ) {\n");
puts("                              if (fi_object_base::bit_vector==true)     \n   ");
puts("                                  m_value=a | fi_object_base::mask;  \n");
puts("                              else   \n ");
puts("				m_value=1;\n");
puts("				static bool runOnce= true;\n");
puts("				if (runOnce==true){\n");
puts("					std::cout<< \"The signal \" <<m_name<< \" is permanently stuck to 1\";\n");
puts("					runOnce=false;}\n");
puts("				}\n");
puts("			}\n");
puts("		else if (fi_object_base::fault_type==\"bit_flip\"){\n");
puts("			if (fi_object_base::injection_time){\n");
puts("				if (VL_TIME_Q()>=fi_object_base::injection_time && VL_TIME_Q()<fi_object_base::release_time) {\n");
puts("                              if (fi_object_base::bit_vector==true)   \n     ");
puts("                                  m_value=a ^ fi_object_base::mask;\n  ");
puts("                              else  { \n  ");
puts("					 m_value=!a;\n");
puts("                                    } \n");
puts("				static bool runOnce= true;\n");
puts("				if (runOnce==true){\n");		
puts("					std::cout<<  \"The signal \" <<m_name<< \" is bit flipped \";\n");
puts("					runOnce=false;}\n");
puts("				}\n");
puts("                          else\n");
puts("                          	m_value=a;\n");
puts("			}\n");
puts("			else{\n             ");		
puts("                  	m_value=a;\n");	
puts("				static bool runOnce= true;\n");
puts("				if (runOnce==true){\n");		
puts("					std::cout<< \"No injection time was specified for bitflip. No fault was injected! \";\n");
puts("					runOnce=false;}\n");
puts("				}\n");
puts("			}\n");
puts("		else if (fi_object_base::fault_type==\"intermittent_sa1\"){//Find a better way to do the checking: VL_TIME_Q can be 1,2,..\n");//Find a better way to do the checking: VL_TIME_Q can be 1,2,..
puts("                 if (VL_TIME_Q()>=fi_object_base::if_inject_time[0] && VL_TIME_Q()< fi_object_base::if_release_time[0]){ \n");
puts("                              if (fi_object_base::bit_vector==true)     \n   ");
puts("                                  m_value=a | fi_object_base::mask; \n ");
puts("                              else  \n  ");
puts("                          m_value=1;\n");
puts("				static bool runOnce= true;\n");
puts("				if (runOnce==true){\n");		
puts("					std::cout<< \"Injecting intermittent fault at signal: \" <<m_name;\n");
puts("					runOnce=false;}\n");
puts(             "}\n");
puts("                 else  {m_value=a;\n");
puts("if (VL_TIME_Q()== fi_object_base::if_release_time[0]){\n");
puts("					fi_object_base::if_inject_time.pop_front();\n");
puts("					fi_object_base::if_release_time.pop_front();}}\n");
puts("              }\n");
puts("		else if (fi_object_base::fault_type==\"intermittent_sa0\"){\n");
puts("                 if (VL_TIME_Q()>=fi_object_base::if_inject_time[0] && VL_TIME_Q()< fi_object_base::if_release_time[0]){\n");
puts("                              if (fi_object_base::bit_vector==true)      \n  ");
puts("                                  m_value=a & fi_object_base::mask; \n ");
puts("                              else  \n  ");
puts("                          m_value=0;\n");
puts("				static bool runOnce= true;\n");
puts("				if (runOnce==true){\n");		
puts("					std::cout<< \"Injecting intermittent fault at signal: \" <<m_name;\n");
puts("					runOnce=false;}\n");
puts(             "}\n");
puts("                 else  {m_value=a;\n");
puts("if (VL_TIME_Q()== fi_object_base::if_release_time[0]){\n");
puts("					fi_object_base::if_inject_time.pop_front();\n");
puts("					fi_object_base::if_release_time.pop_front();}}\n");
puts("              }\n");
puts("		else if (fi_object_base::fault_type==\"intermittent_bf\"){\n");
puts("                 if (VL_TIME_Q()>=fi_object_base::if_inject_time[0] && VL_TIME_Q()< fi_object_base::if_release_time[0]){\n");
puts("                              if (fi_object_base::bit_vector==true)   \n     ");
puts("                                  m_value=a ^ fi_object_base::mask;\n  ");
puts("                              else  { \n  ");
puts("					 m_value=!a;}\n");
puts("				static bool runOnce= true;\n");
puts("				if (runOnce==true){\n");		
puts("					std::cout<< \"Injecting intermittent fault at signal: \" <<m_name;\n");
puts("					runOnce=false;}\n");
puts(             "}\n");
puts("                 else  {m_value=a;\n");
puts("if (VL_TIME_Q()== fi_object_base::if_release_time[0]){\n");
puts("					fi_object_base::if_inject_time.pop_front();\n");
puts("					fi_object_base::if_release_time.pop_front();}}\n");
puts("              }\n");
puts("		else {\n");
puts("			m_value=a;\n");
puts("			static bool runOnce= true;\n");
puts("			if (runOnce==true){\n");
puts("				std::cout<< \"Injection type was not specified. No fault was injected! \";\n");
puts("				runOnce=false;}\n");
puts("			}\n");
puts("	}\n");
puts("	else {\n");
puts("		m_value=a;\n");
puts("			}\n");
puts("	return *this;\n");
puts("    }\n");
puts("    \n");
puts("    virtual std::string name() {\n");
puts("    	return m_name;\n");
puts("    }\n");
puts("    \n");
puts("    \n");
puts("    \n");
puts("    \n");
puts("    \n");
puts("    inline operator QData()\n");
puts("    const{ return m_value; }\n");
puts("    \n");
puts("    inline unsigned char c_str()\n");
puts("    { return static_cast<unsigned char>(m_value); }\n");
puts("    \n");
puts("    \n");
puts("    inline T get_value() { return m_value; }\n");
puts("    \n");
puts("    \n");
puts("  private:\n");
puts("    T m_value;\n");
puts("    std::string m_name;\n");
puts("    std::string m_v;\n");
puts("};\n");
puts("\n");
}
