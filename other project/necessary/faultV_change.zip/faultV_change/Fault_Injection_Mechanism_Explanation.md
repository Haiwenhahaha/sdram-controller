# Fault Injection Implementation Mechanism Explanation

This document provides a detailed explanation of the implementation mechanism of Verilator's fault injection functionality, serving as a supplement to `Fault_Injection_Modification_Confirmation.md`.

## I. Overall Architecture

The fault injection functionality modifies Verilator's code generation process to insert fault injection logic into the generated C++ code. The entire implementation is divided into three phases:

### 1. Compile-Time Marking Phase (AST Processing)

**Purpose**: Identify which signals need to support fault injection

**Implementation locations**:
- `V3AstNodeOther.h`: Add `m_fi` flag bit to `AstVar` class
- `V3LinkLevel.cpp`: Mark IO signals during linking phase
- `V3Options.cpp/h`: Add `-fi` command-line option

**Workflow**:
```
User input: verilator -fi design.v
    ↓
V3Options.cpp: Parse -fi option, set m_fault_injection = true
    ↓
V3LinkLevel.cpp: Traverse all IO signals, call varp->fi(true)
    ↓
Result: Variable nodes in AST are marked as fault-injectable
```

### 2. Code Generation Phase (C++ Code Generation)

**Purpose**: Declare marked signals as `fi_object<T>` types and generate fault injection class definitions

**Implementation locations**:
- `V3EmitCModel.cpp`: Generate `fi_object` class definitions and static member variables
- `V3EmitCBase.cpp`: Modify signal declarations, replace normal types with `fi_object<T>`
- `V3EmitCFunc.h`: Handle type conversion issues

**Workflow**:
```
V3EmitCModel.cpp::emitHeader():
    ↓
Generate fi_object_base and fi_object<T> class definitions
    ↓
V3EmitCBase.cpp::emitVarDecl():
    ↓
Check varp->isFi() or v3Global.opt.fault_injection()
    ↓
Generate: fi_object<IData> signal_name;  // Instead of IData signal_name;
    ↓
V3EmitCModel.cpp::emitImplementation():
    ↓
Generate static member variable definitions (provide global state for fault injection)
```

### 3. Runtime Injection Phase (Simulation Execution)

**Purpose**: Dynamically inject faults during simulation according to configuration

**Implementation mechanism**: C++ operator overloading

**Workflow**:
```
Generated code: fi_object<IData> internal_reg("internal_reg");
                internal_reg = some_value;  // Triggers operator=
    ↓
fi_object::operator=() executes:
    1. Check m_name == injection_location
    2. Check if VL_TIME_Q() is within [injection_time, release_time] range
    3. Apply fault according to fault_type:
       - "sa0": m_value = 0
       - "sa1": m_value = 1
       - "bit_flip": m_value = !a
       - ...
    4. Return *this
    ↓
When subsequent code reads internal_reg:
    ↓
operator QData() returns m_value (value with fault injected)
```

## II. Key Technical Points

### 1. Operator Overloading Interception Mechanism

**Core principle**:
- C++'s assignment operator `operator=` is called on every assignment
- No matter how complex the right-hand side expression is, the right-hand side value is calculated first, then `operator=` is called
- This ensures all assignment operations can be intercepted

**Example**:
```cpp
// Generated code might be:
fi_object<IData> reg_a("reg_a");
IData complex_expr = (a + b) * c - d;

// This line triggers operator=
reg_a = complex_expr;
// Equivalent to: reg_a.operator=(complex_expr);
// Inside operator=, complex_expr has already been calculated
```

### 2. Type System Design

**Why use template class `fi_object<T>`?**
- Supports signals of different bit widths (8-bit, 16-bit, 32-bit, 64-bit)
- Maintains type safety, avoids type conversion errors
- Compile-time optimization, no runtime type checking overhead

**Type mapping**:
- `CData` (8-bit) → `fi_object<CData>`
- `SData` (16-bit) → `fi_object<SData>`
- `IData` (32-bit) → `fi_object<IData>`
- `QData` (64-bit) → `fi_object<QData>`

### 3. Static Member Variable Design

**Why use static member variables?**
- All `fi_object` instances share the same fault configuration
- Users only need to configure once, all signals can access it
- Simplifies API, no need to pass configuration objects

**Configuration flow**:
```cpp
// User configures in wrapper:
fi_object_base::injection_location = "internal_reg";
fi_object_base::fault_type = "sa0";
fi_object_base::injection_time = 100;
fi_object_base::release_time = 200;

// All fi_object instances can access these configurations in operator=
```

### 4. Time Control Mechanism

**Simulation time acquisition**:
- Use Verilator's internal macro `VL_TIME_Q()` to get current simulation time
- This is a global variable updated at each clock edge

**Time window judgment**:
```cpp
if (VL_TIME_Q() >= injection_time && VL_TIME_Q() < release_time) {
    // Within fault injection time window
    apply_fault();
} else {
    // Normal value
    m_value = a;
}
```

### 5. Local Variable Filtering

**Why is filtering needed?**
- Verilator generates many internal temporary variables (such as `__Vtemp*`, `__Vdly*`)
- These variables should not be injected with faults, otherwise simulation errors will occur
- Identify and exclude these variables through name prefix matching

**Filtering rules**:
```cpp
bool local_variable = (
    av_name_prefix == "__VinpClk__" ||    // Clock related
    av_name_prefix2 == "__Vclklast__" ||  // Previous cycle value
    av_name_prefix2 == "__Vchglast__" ||  // Change detection
    av_name == "__Vm_traceActivity" ||     // Trace flag
    av_name_prefix3 == "__Vtemp" ||       // Temporary variables
    av_name_prefix4 == "__Vdly" ||        // Delay variables
    av_name_prefix4 == "__Vilp"           // Internal variables
);
```

## III. Fault Type Implementation

### 1. Stuck-at-0 (SA0)
```cpp
if (fault_type == "sa0") {
    m_value = (bit_vector) ? (a & mask) : 0;
}
```
- Bit vector mode: Use `mask` to inject fault only to specific bits
- Scalar mode: Entire signal is fixed to 0

### 2. Stuck-at-1 (SA1)
```cpp
if (fault_type == "sa1") {
    m_value = (bit_vector) ? (a | mask) : 1;
}
```
- Bit vector mode: Use `mask` to inject fault only to specific bits
- Scalar mode: Entire signal is fixed to 1

### 3. Bit-flip
```cpp
if (fault_type == "bit_flip") {
    m_value = (bit_vector) ? (a ^ mask) : !a;
}
```
- Bit vector mode: Use `mask` to flip only specific bits
- Scalar mode: Flip entire signal

### 4. Intermittent Faults
```cpp
if (fault_type == "intermittent_sa0") {
    if (VL_TIME_Q() >= if_inject_time[0] && VL_TIME_Q() < if_release_time[0]) {
        m_value = (bit_vector) ? (a & mask) : 0;  // Inject fault
    } else {
        m_value = a;  // Normal value
        if (VL_TIME_Q() == if_release_time[0]) {
            // Remove completed fault time window
            if_inject_time.pop_front();
            if_release_time.pop_front();
        }
    }
}
```
- Use `std::deque` to store multiple time windows
- Supports multiple intermittent fault sequences
- Automatically manages time window lifecycle

## IV. Relationships Between Modification Points

```
┌─────────────────────────────────────────────────────────────┐
│                    User Command Line Input                  │
│              verilator -fi design.v                         │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  V3Options.cpp/h: Parse -fi Option                         │
│  - Set m_fault_injection = true                             │
│  - Provide fault_injection() accessor                      │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  V3LinkLevel.cpp: Mark IO Signals                          │
│  - Traverse top-level IO ports                              │
│  - Call varp->fi(true) to mark                              │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  V3AstNodeOther.h: Provide Marking Mechanism                │
│  - Define m_fi member variable                              │
│  - Provide fi() and isFi() methods                         │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  V3EmitCModel.cpp: Generate Fault Injection Class Defs      │
│  - emitHeader(): Generate fi_object class definition         │
│  - emitImplementation(): Generate static member defs        │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  V3EmitCBase.cpp: Modify Signal Declarations               │
│  - emitVarDecl(): Check isFi() or fault_injection()        │
│  - Generate fi_object<T> type declarations                  │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  V3EmitCFunc.h: Handle Type Conversions                    │
│  - visit(AstCond*): Add (IData) type conversion             │
│  - Resolve ternary operator type mismatch issues            │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│          Generated C++ Code (Compilable and Runnable)      │
│  - All signals declared as fi_object<T> types              │
│  - Each assignment triggers operator=, checks and applies   │
│    faults                                                   │
└─────────────────────────────────────────────────────────────┘
```

## V. Design Advantages

1. **Transparency**: Completely transparent to user code, no need to modify RTL design
2. **Flexibility**: Supports multiple fault types and time control
3. **Performance**: Compile-time optimization, small runtime overhead (only conditional checks)
4. **Extensibility**: Easy to add new fault types
5. **Compatibility**: Does not affect normal simulation (when fault injection is not enabled)

## VI. Potential Issues and Limitations

1. **Type conversion issues**: Some complex expressions may require explicit type conversion (resolved through Modification 2)
2. **Wide signal limitations**: Current implementation does not support fault injection for wide signals (arrays)
3. **Local variable filtering**: Name prefix-based filtering may not be precise enough
4. **Performance impact**: Each assignment has conditional checks, may slightly affect simulation speed

## VII. Usage Example

```cpp
// 1. Use Verilator to generate code (with -fi option)
// verilator -fi --cc your_design.v

// 2. Configure faults in wrapper
#include "Vyour_design.h"

int main() {
    Vyour_design* top = new Vyour_design;
    
    // Configure fault injection
    fi_object_base::injection_location = "Top__DOT__internal_reg";
    fi_object_base::fault_type = "sa0";
    fi_object_base::injection_time = 100;
    fi_object_base::release_time = 200;
    
    // Run simulation
    for (int i = 0; i < 300; i++) {
        top->eval();
        // Between time 100-200, internal_reg will be fixed to 0
    }
    
    return 0;
}
```

