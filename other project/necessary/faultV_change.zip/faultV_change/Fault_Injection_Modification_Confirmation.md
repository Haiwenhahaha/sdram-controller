# Verilator Fault Injection Modification Confirmation

## Document Description

This document records all code modifications required to port the fault injection functionality from `verilator-fault_simulation` to `verilator-master`.

**Reference Sources**:
- `verilator-fault_simulation`: Fault injection implementation based on an older version of Verilator
- `verilator-master`: Latest version of Verilator (code structure has been refactored)

**Note**: Due to version differences, some file locations and code structures have changed. This document has re-confirmed all modification locations.

---

## Modification Overview

### Core Mechanism (Brief Description)

The fault injection functionality is implemented through the following mechanisms:

1. **Marking Phase**: Add markers (`m_fi` flag) to signals that need fault injection during AST processing
2. **Type Replacement**: Replace normal signal types (`CData`/`SData`/`IData`/`QData`) with `fi_object<T>` types during code generation
3. **Operator Interception**: Intercept and apply faults on each signal assignment through C++ operator overloading
4. **Runtime Control**: Control fault injection timing, location, and type through static member variables

**For detailed mechanism explanation, please refer to `Fault_Injection_Mechanism_Explanation.md`.**

---

## Modified Files List

Modified files:
- V3AstNodeOther.h  (Note: In verilator-master, the corresponding file is V3AstNodeOther.h, not V3AstNodes.h) 
- V3LinkLevel.cpp 
- V3Options.cpp 
- V3Options.h 
- V3EmitCBase.cpp (modify emitVarDecl function)
- V3EmitCModel.cpp (add header files, fi_object class definition, static member variable definitions)
- V3EmitCFunc.h (add type conversion)

ref:
https://github.com/verilator/verilator/pull/2724/commits/2c23fd7e36e4d0f724deda29b80e5defc643e57e#diff-2593cae5cd0fe27a6dec20c6477eedbec56537820caf1a58d3a65a43d9ceacd3



## V3AstNodeOther.h (Corresponding File in verilator-master)

**Note**: In `verilator-fault_simulation`, the `AstVar` class is defined in `V3AstNodes.h`, but in `verilator-master`, the `AstVar` class is defined in `V3AstNodeOther.h`.

### Modification 1: Add Member Variable

**File**: `verilator-master/src/V3AstNodeOther.h`

**Location**: In the private member variable section of the `AstVar` class, after `m_trace` (line 1916)

**Modification Content**:
```cpp
bool m_trace : 1;  // Trace this variable
bool m_fi : 1;     // Fault injection flag (fi)
bool m_isLatched : 1;  // Not assigned in all control paths of combo always
```

### Modification 2: Initialize in init() Function

**Location**: In the `AstVar::init()` function, after `m_trace = false;` (line 1969)

**Modification Content**:
```cpp
m_trace = false;
m_fi = false;  // Fault injection flag initialization (fi)
m_isLatched = false;
```

### Modification 3: Add Setter Method

**Location**: In the public method section of the `AstVar` class, near the `trace()` method (line 2129)

**Modification Content**:
```cpp
void trace(bool flag) { m_trace = flag; }
void fi(bool flag) { m_fi = flag; }  // Fault injection setter (fi)
void isLatched(bool flag) { m_isLatched = flag; }
```

### Modification 4: Add Getter Method

**Location**: In the public method section of the `AstVar` class, after the `isTrace()` method (line 2220)

**Modification Content**:
```cpp
bool isTrace() const { return m_trace; }
bool isFi() const { return m_fi; }  // Fault injection getter (fi)
bool isRand() const { return m_rand.isRand(); }
```

**Reference**: verilator-fault_simulation/src/V3AstNodes.h
- Line 1952: `bool m_fi:1; //fi` - Member variable declaration
- Line 1992: `m_fi = false; //fi` - Initialization in init() function
- Line 2118: `void fi(bool flag) { m_fi = flag; } //fi` - Setter method
- Line 2190: `bool isFi() const { return m_fi; }//fi` - Getter method



## V3LinkLevel.cpp

### Modification Location: Add Fault Injection Marking in wrapTopCell() Function

**File**: `verilator-master/src/V3LinkLevel.cpp`

**Location**: In the `wrapTopCell()` function, approximately lines 298-300 (after checking `isRef()`, before `systemC()` check)

**Modification Content**:
```cpp
if (varp->isRef() || varp->isConstRef()) {
    varp->v3warn(E_UNSUPPORTED,
                 "Unsupported: ref/const ref as primary input/output: "
                     << varp->prettyNameQ());
}
if (v3Global.opt.fault_injection()) {  // fi
    varp->fi(true);
}
if (varp->isIO() && v3Global.opt.systemC()) {
    varp->sc(true);
    // ...
}
```

### Code Explanation

#### 1. Code Context

This code is located in the `V3LinkLevel::wrapTopCell()` function, which:
- **Creates top-level wrapper module**: Creates a new wrapper module (`$root`) for the original top-level module
- **Promotes IO ports**: Promotes IO ports from the original top-level module to the new wrapper module
- **Creates connections**: Connects new module ports to original module ports through `AstPin`

#### 2. Code Location and Purpose

**Location**: After creating the new `varp` (cloned from the original module's `oldvarp`) and setting its attributes:

```cpp
// 1. Clone original variable
AstVar* const varp = oldvarp->cloneTree(false);

// 2. Set variable attributes
varp->name(name);
varp->protect(false);
newmodp->addStmtsp(varp);
varp->sigPublic(true);
oldvarp->primaryIO(false);
varp->primaryIO(true);

// 3. Check ref/const ref (not supported)
if (varp->isRef() || varp->isConstRef()) {
    varp->v3warn(E_UNSUPPORTED, ...);
}

// 4. [Fault Injection Marking] If fault injection is enabled, mark this variable
if (v3Global.opt.fault_injection()) {  // fi
    varp->fi(true);  // Set fault injection flag
}

// 5. Other attribute settings (SystemC, trace, etc.)
if (varp->isIO() && v3Global.opt.systemC()) {
    varp->sc(true);
    // ...
}
```

#### 3. Code Function Details

**`if (v3Global.opt.fault_injection())`**:
- **Check condition**: Determines whether the user has enabled fault injection using the `-fi` option in the command line
- **`v3Global.opt.fault_injection()`**: Returns `true` if fault injection is enabled, `false` otherwise

**`varp->fi(true)`**:
- **Purpose**: Sets the fault injection flag `m_fi` of variable `varp` to `true`
- **Meaning**: Marks this variable as a **target for fault injection**
- **Subsequent impact**: When generating code in `V3EmitC.cpp`, it will check `varp->isFi()` to decide whether to declare this variable as `fi_object<type>`

#### 4. Why Add Here?

**Timing selection**:
- ✅ **After variable creation**: At this point, `varp` has been created and added to the new module
- ✅ **After attribute setting**: Attributes like `primaryIO(true)` have been set, variable is ready
- ✅ **During IO port promotion**: Ensures all IO ports promoted to the top level are marked

**Scope**:
- Only marks **IO ports promoted to the top-level wrapper module**
- These ports are the main targets that users can access and inject faults into
- Internal signals will be handled according to other conditions in `V3EmitC.cpp`

#### 5. Relationship with Other Modifications

- **V3AstNodeOther.h**: Defines the `m_fi` member variable and `fi()`, `isFi()` methods
- **V3LinkLevel.cpp** (here): Sets the `fi(true)` flag when creating variables
- **V3EmitCBase.cpp**: Checks `isFi()` when generating code to decide whether to use `fi_object<type>`

**For detailed workflow, please refer to `Fault_Injection_Mechanism_Explanation.md`.**

**Reference**: verilator-fault_simulation/src/V3LinkLevel.cpp
- Lines 229-231: `if (v3Global.opt.fault_injection()) { varp->fi(true); }`


## V3Options.cpp

### Modification Location: Add `-fi` Command-Line Option Parsing

**File**: `verilator-master/src/V3Options.cpp`

**Location**: In the `parseOptsList()` function, line 1325 (after the `-cc` option)

**Modification Content**:
```cpp
DECL_OPTION("-cc", CbCall, [this]() { ccSet(); });
DECL_OPTION("-fi", CbCall, [this]() { m_fault_injection = true; });  // Fault injection
DECL_OPTION("-clk", CbVal, [fl](const std::string&) {
    // ...
});
```

### Code Explanation

#### 1. Option Parsing System

**New version Verilator uses `DECL_OPTION` macro system**:
- `verilator-fault_simulation` uses the old string comparison method (`strcmp`)
- `verilator-master` uses the new `V3OptionParser` system
- The new system is more flexible and supports auto-completion and error hints

#### 2. `-fi` Option Definition

**`DECL_OPTION("-fi", CbCall, [this]() { m_fault_injection = true; })`**:
- **`"-fi"`**: Command-line option name, users use `verilator -fi design.v` to enable fault injection
- **`CbCall`**: Callback type, indicating this is a parameterless option (similar to `-cc`, `-sc`)
- **`[this]() { m_fault_injection = true; }`**: Lambda function executed when the `-fi` option is parsed
  - Sets the `m_fault_injection` member variable to `true`
  - Indicates that the user has enabled fault injection functionality

#### 3. Relationship with Other Modifications

- **V3Options.h**: Defines the `m_fault_injection` member variable and `fault_injection()` accessor
- **V3LinkLevel.cpp**: Checks whether fault injection is enabled through `v3Global.opt.fault_injection()`
- **V3EmitCBase.cpp**: Decides whether to generate `fi_object<T>` types through `v3Global.opt.fault_injection()`

**For detailed workflow, please refer to `Fault_Injection_Mechanism_Explanation.md`.**



**Reference**: verilator-fault_simulation/src/V3Options.cpp
- Lines 988-989: `} else if ( !strcmp (sw, "-fi") ) { m_fault_injection = true; }`
- **Note**: Old version uses string comparison, new version uses `DECL_OPTION` system

## V3Options.h

### Modification 1: Add Member Variable

**File**: `verilator-master/src/V3Options.h`

**Location**: In the private member variable section of the `V3Options` class, line 312 (after `m_xInitialEdge`)

**Modification Content**:
```cpp
bool m_xInitialEdge = false;    // main switch: --x-initial-edge
bool m_fault_injection = false;  // main switch: -fi (fault injection)
```

### Modification 2: Add Accessor Method

**Location**: In the public accessor method section of the `V3Options` class, line 589 (after `xInitialEdge()`)

**Modification Content**:
```cpp
bool xInitialEdge() const { return m_xInitialEdge; }
bool fault_injection() const { return m_fault_injection; }  // Fault injection flag accessor
```

### Code Explanation

#### 1. Member Variable `m_fault_injection`

**`bool m_fault_injection = false;`**:
- **Type**: `bool`, boolean value indicating whether fault injection is enabled
- **Default value**: `false`, fault injection is disabled by default
- **Purpose**: Stores whether the user has used the `-fi` option in the command line
- **Naming**: Uses underscore separation (`m_fault_injection`), following Verilator's naming convention

#### 2. Accessor Method `fault_injection()`

**`bool fault_injection() const { return m_fault_injection; }`**:
- **Return type**: `bool`, returns the state of the fault injection flag
- **`const`**: Method does not modify object state, only reads
- **Purpose**: Provides read-only access to the private member variable
- **Usage scenario**:
  ```cpp
  if (v3Global.opt.fault_injection()) {
      // Enable fault injection related functionality
      varp->fi(true);
  }
  ```

#### 3. Relationship with Other Member Variables

- **`m_systemC`**: SystemC output format flag
- **`m_trace`**: Waveform tracing flag
- **`m_vpi`**: VPI interface flag
- **`m_fault_injection`**: Fault injection flag (newly added)

#### 4. Access Pattern

**Verilator's option access pattern**:
- Member variable: `m_xxx` (private, used internally in class)
- Accessor: `xxx()` (public, used by external code)
- Global access: `v3Global.opt.xxx()` (accessed through global object)

**Reference**: verilator-fault_simulation/src/V3Options.h
- Line 323: `bool m_fault_injection = false; //fi` - Member variable declaration
- Line 445: `bool fault_injection() const { return m_fault_injection; }//fi` - Accessor method


## V3EmitC Related File Modifications

### File Mapping Description

**Note**: In `verilator-fault_simulation`, all code generation logic is in `V3EmitC.cpp`. However, in the new version `verilator-master`, code generation has been split into multiple modular files:

- **`V3EmitC.h`** / **`V3EmitCBase.h`**: Header files, declare code generation related classes and functions
- **`V3EmitCBase.cpp`**: Basic code generation, including variable declarations, type conversions, etc.
- **`V3EmitCClass.cpp`**: Class member variable and method generation
- **`V3EmitCModel.cpp`**: Model-related code generation (header files, class definitions, static member variable definitions, etc.)
- **`V3EmitCFunc.cpp`** / **`V3EmitCFunc.h`**: Function body code generation (including expressions, conditional statements, etc.)
- **`V3EmitCMain.cpp`**: Main function generation
- **`V3EmitCInlines.cpp`**: Inline function generation

**Reference**: verilator-fault_simulation/src/V3EmitC.cpp

### Actually Modified Files List

5. **`V3EmitCBase.cpp`** ✅
   - Line 23: Add `#include <deque>` (for supporting intermittent fault time arrays)
   - Lines 200-219: Modify IO signal declarations to `fi_object<T>` type
   - Lines 234-280: Modify internal signal declarations to `fi_object<T>` type (excluding local variables)

6. **`V3EmitCModel.cpp`** ✅
   - Lines 75-85: Add fault injection required header file includes in `emitHeader()` function
   - Lines 94-400: Add `fi_object_base` and `fi_object<T>` class definitions in `emitHeader()` function
   - Lines 872-884: Add static member variable definitions in `emitImplementation()` function

7. **`V3EmitCFunc.h`** ✅
   - Lines 1477-1481: Add `(IData)` type conversion in `visit(AstCond* nodep)` function
   - Used to resolve type mismatch issues between `fi_object` and `unsigned int` in ternary operators



### Modification 1: Version Declaration and Header File Includes

**Corresponding File**: `verilator-master/src/V3EmitCBase.cpp` or `V3EmitCBase.h`

**Reference Location**: verilator-fault_simulation/src/V3EmitC.cpp
- Lines 15-23: Version origin declaration (copyright information)
- Line 42: `#include <deque> //fi`

**Code Explanation**:
- **Version declaration**: Added modification copyright notice from Infineon Technologies AG
- **`#include <deque>`**: Include `std::deque` container for storing intermittent fault time arrays
  - `std::deque` supports efficient `pop_front()` operations, suitable for managing fault injection and release time sequences
  - Used for `fi_object_base::if_inject_time` and `fi_object_base::if_release_time`

**Location in verilator-master**:
- ✅ **Modified**: 
  - `V3EmitCBase.cpp` line 23: Add `#include <deque>` at the source file header (for supporting fault injection functionality)
  - `V3EmitCModel.cpp` lines 75-85: Add fault injection required header file includes in `emitHeader()` function (generated to output files)

### Modification 2: Type Conversion (fi_object to IData)

**Location in verilator-master**:
- ✅ **Modified**: `V3EmitCFunc.h` lines 1477-1481, add type conversion in `visit(AstCond* nodep)` function
- Location: After `putbs(" ? ");`, before `iterateAndNextConstNull(nodep->thenp());`

**Reference Location**: verilator-fault_simulation/src/V3EmitC.cpp lines 1001-1006

**Code Content**:
```cpp
//Since there could be a comparison to unsigned int, convert fi_object to IData to fix compiler errors. Is there a better way?
if (v3Global.opt.fault_injection()){//fi
    if (!nodep->isQuad()) {
        puts("(IData)");
    } 
}
```

**Code Explanation**:

#### 1. Problem Background

**Why is this type conversion needed?**

When `fi_object<T>` types are used in ternary operators (conditional expressions), type matching issues may occur:

```cpp
// Generated code might look like this:
fi_object<IData> signal_a;
unsigned int value = 100;

// Ternary operator: condition ? signal_a : value
// or: condition ? value : signal_a
```

**Problem**:
- The `fi_object<T>` class only has one `operator QData()` type conversion operator (line 325)
- When `fi_object<IData>` needs to be compared with or participate in ternary operations with `unsigned int`, the C++ compiler may not be able to automatically find a suitable conversion path
- Although `fi_object<IData>` → `QData` → `IData` is logically feasible, the compiler may not be able to automatically infer this conversion chain

#### 2. Specific Scenario

**Ternary operator type requirements**:
```cpp
// C++ requires both branches of the ternary operator to be compatible types
condition ? expr1 : expr2
// expr1 and expr2 must be convertible to the same type
```

**Example problematic code**:
```cpp
// Assuming generated code is:
fi_object<IData> internal_reg;
unsigned int threshold = 10;

// This line may fail to compile:
unsigned int result = (some_condition) ? internal_reg : threshold;
// Error: Cannot convert between fi_object<IData> and unsigned int
```

**Solution**:
```cpp
// Add explicit type conversion:
unsigned int result = (some_condition) ? (IData)internal_reg : threshold;
// Now it compiles: fi_object<IData> → operator QData() → (IData) → unsigned int
```

#### 3. Why Only Add for Non-64-bit?

- **64-bit (`isQuad()`)**: `fi_object<QData>` already has `operator QData()`, can convert directly
- **32-bit and below**: `fi_object<IData>`, `fi_object<SData>`, `fi_object<CData>` need to convert to `QData` first, then to target type, compiler may not automatically infer

#### 4. Pros and Cons of Current Method

**Pros**:
- ✅ Simple and direct, explicitly tells compiler about type conversion
- ✅ No need to modify `fi_object` class definition
- ✅ Only adds conversion where actually needed (ternary operators)
- ✅ Won't introduce unexpected implicit conversions
- ✅ Code intent is clear, easy to maintain

**Cons**:
- ❌ Need to add conversion at each potentially problematic location
- ❌ Need to insert conversion at specific positions during code generation

**Note**: If more type conversion-related compilation errors are encountered later, consider adding more type conversion operators to the `fi_object` class (see `fi_object类型转换改进方案.md`).



### Modification 3: IO Signal Declaration as fi_object Type

**Location in verilator-master**:
- ✅ **Modified**: `V3EmitCBase.cpp` lines 200-219, add IO signal `fi_object<T>` type declaration in `emitVarDecl()` function
- Location: Add new conditional branch before `else if (nodep->isIO() && basicp && !basicp->isOpaque())`

**Reference Location**: verilator-fault_simulation/src/V3EmitC.cpp lines 1915-1925

**Code Content**:
```cpp
} else if (nodep->isIO() && v3Global.opt.fault_injection() && !nodep->isWide() ) {//fi
    m_ctorVarsVec.push_back(nodep);
    if (nodep->isQuad()) puts("fi_object<QData> ");
    else if (nodep->widthMin() <= 8) puts("fi_object<CData> ");
    else if (nodep->widthMin() <= 16) puts("fi_object<SData> ");
    else puts("fi_object<IData> ");
    puts(nodep->name());
    puts(";\n");
    emitDeclArrayBrackets(nodep);
```

**Code Explanation**:
- **Function**: Declare IO port signals as `fi_object<T>` type instead of normal `CData`/`SData`/`IData`/`QData`
- **Conditions**:
  - `nodep->isIO()`: Must be an IO port
  - `v3Global.opt.fault_injection()`: Fault injection is enabled
  - `!nodep->isWide()`: Not a wide signal (array), only handles scalars or small arrays
- **Type selection**:
  - `QData`: 64-bit (`isQuad()`)
  - `CData`: 8-bit (`widthMin() <= 8`)
  - `SData`: 16-bit (`widthMin() <= 16`)
  - `IData`: 32-bit (other cases)
- **`m_ctorVarsVec.push_back(nodep)`**: Add variable to constructor variable list for subsequent initialization
- **`emitDeclArrayBrackets(nodep)`**: Generate array dimension declarations (e.g., `[7:0]`)


### Modification 4: Internal Signal Declaration as fi_object Type (Excluding Local Variables)

**Location in verilator-master**:
- ✅ **Modified**: `V3EmitCBase.cpp` lines 234-280, add internal signal `fi_object<T>` type declaration in the `else` branch of `emitVarDecl()` function
- Location: Add `else if (v3Global.opt.fault_injection())` branch before the original `else` branch

**Reference Location**: verilator-fault_simulation/src/V3EmitC.cpp lines 1954-1990

**Code Content**:
```cpp
} else if (v3Global.opt.fault_injection()) {//fi
    std::string av_name = nodep->name();
    std::string last_char = nodep->vlArgType(true, false, false, prefixIfImp);
    std::string av_name_prefix = av_name.substr(0,11);
    std::string av_name_prefix2 = av_name.substr(0,12);
    std::string av_name_prefix3 = av_name.substr(0,7);
    std::string av_name_prefix4 = av_name.substr(0,6);
    bool local_variable = (av_name_prefix == "__VinpClk__" ||
                          av_name_prefix2 == "__Vclklast__" ||
                          av_name_prefix2 == "__Vchglast__" ||
                          av_name == "__Vm_traceActivity" ||
                          av_name_prefix3 == "__Vtemp" ||
                          av_name_prefix4 == "__Vdly" ||
                          av_name_prefix4 == "__Vilp");

    if (v3Global.opt.fault_injection() && !local_variable && !nodep->isWide() 
        && last_char.substr(last_char.length()-1) != "]" ) {
        m_ctorVarsVec.push_back(nodep);
        if (nodep->widthMin() <= 8) {
            puts("fi_object<CData> ");
        } else if (nodep->widthMin() <= 16) {
            puts("fi_object<SData> ");
        } else if (nodep->isQuad()) {
            puts("fi_object<QData> ");
        } else {
            puts("fi_object<IData> ");
        }
        puts(nodep->nameProtect());
    } else {
        puts(nodep->vlArgType(true, false, false, prefixIfImp));
        puts(";\n");
    }
    if (v3Global.opt.fault_injection() && !local_variable && !nodep->isWide()) {
        puts(";\n");
    }
}
```

**Code Explanation**:
- **Function**: Declare internal signals (non-IO) as `fi_object<T>` type, but exclude Verilator-generated temporary variables
- **Local variable filtering**: Exclude the following Verilator internally generated variables:
  - `__VinpClk__*`: Clock input related
  - `__Vclklast__*`: Previous clock cycle value
  - `__Vchglast__*`: Change detection related
  - `__Vm_traceActivity`: Trace activity flag
  - `__Vtemp*`: Temporary variables
  - `__Vdly*`: Delay variables
  - `__Vilp*`: Internal variables
- **Condition checks**:
  - `!local_variable`: Not a local/temporary variable
  - `!nodep->isWide()`: Not a wide signal
  - `last_char != "]"`: Avoid multi-dimensional arrays (simplified handling)
- **Type selection**: Same as IO signals, select `CData`/`SData`/`IData`/`QData` based on bit width
- **`nameProtect()`**: Use protected name (handles C++ keyword conflicts)



### Modification 5: fi_object_base Static Member Variable Definitions

**Location in verilator-master**:
- ✅ **Modified**: `V3EmitCModel.cpp` lines 872-884, add static member variable definitions in `emitImplementation()` function
- Location: After `#include` statements, at the beginning of function body

**Reference Location**: verilator-fault_simulation/src/V3EmitC.cpp lines 2800-2813

**Code Content**:
```cpp
if (v3Global.opt.fault_injection()){ //fi
    puts("fi_object_base::ffs_keys_t fi_object_base::ffs_keys;\n");
    puts("unsigned int fi_object_base::counter = 0;\n");
    puts("QData fi_object_base::injection_time = 0;\n");
    puts("QData fi_object_base::release_time = 0;\n");
    puts("std::string fi_object_base::injection_location = \"\";\n");
    puts("std::string fi_object_base::fault_type = \"\";\n");
    puts("unsigned int fi_object_base::mask = 0;\n");
    puts("bool fi_object_base::bit_vector = {};\n");
    puts("std::deque<QData> fi_object_base::if_release_time = {0};\n");
    puts("std::deque<QData> fi_object_base::if_inject_time = {0};\n");
}
```

**Code Explanation**:

#### 1. Why Place in `emitImplementation()` Function?

**C++ static member variable rules**:
- **Declaration**: In class definition (header file generated by `emitHeader()`)
- **Definition**: In implementation file (`.cpp` file generated by `emitImplementation()`)
- If defined in header file, it will cause duplicate definition errors

**For detailed explanation, please refer to the "Static Member Variable Design" section in `Fault_Injection_Mechanism_Explanation.md`.**

#### 2. Purpose of This Code

**Function**: Allocate storage space and initialize static member variables of the `fi_object_base` class

**Static member variable description**:
- **`ffs_keys`**: Fault injection target signal name list (`std::vector<std::string>`)
  - Used to store names of all signals that can be injected with faults
- **`counter`**: Fault injection counter
  - Used to count the number of registered fault injection targets
- **`injection_time`**: Fault injection start time (`QData` = 64-bit)
  - Specifies when to start injecting faults
- **`release_time`**: Fault release time
  - Specifies when to stop injecting faults
- **`injection_location`**: Fault injection location (signal name)
  - Specifies the target signal name for fault injection
- **`fault_type`**: Fault type string
  - Possible values: "sa0", "sa1", "bit_flip", "intermittent_sa0", "intermittent_sa1", "intermittent_bf"
- **`mask`**: Bit mask (for partial bit fault injection)
  - Used to specify which bits need fault injection
- **`bit_vector`**: Whether to use bit vector mode
  - `true`: Use `mask` for partial bit fault injection
  - `false`: Inject fault to entire signal
- **`if_inject_time`**: Intermittent fault injection time array (`std::deque<QData>`)
  - Stores injection times for multiple intermittent faults
- **`if_release_time`**: Intermittent fault release time array
  - Stores release times for multiple intermittent faults

**Initialization**:
- All variables have default initial values (0 or empty string)
- These values will be overwritten by user configuration at runtime

**Note**: These static member variables are already declared in `emitHeader()` (in class definition), here they are only defined (storage space allocated).





### Modification 6: Conditional Compilation and Header File Includes

**Location in verilator-master**:
- ✅ **Modified**: `V3EmitCModel.cpp` lines 75-85, add fault injection required header files in `emitHeader()` function
- Location: Together with other `#include` statements, before class declarations

**Reference Location**: verilator-fault_simulation/src/V3EmitC.cpp
- Line 3070: `if (!v3Global.opt.fault_injection()){//fi`
- Line 3088: ` }`
- Lines 3162-3173: Header file includes

**Code Content**:
```cpp
// Around line 3070: Conditional compilation (some code only generated in non-fault-injection mode)
if (!v3Global.opt.fault_injection()){//fi
    // ... normal code generation ...
}

// Lines 3162-3173: Header files required for fault injection
if (v3Global.opt.fault_injection()) { //fi
    puts("#include <map>\n");
    puts("#include <string>\n");
    puts("#include <fstream>\n");
    puts("#include <sstream>\n");
    puts("#include <vector>\n");
    puts("#include <deque>\n");
    puts("#include <cstdlib>\n");
    puts("#include <ctime>\n");
    puts("\n");
}
```

**Code Explanation**:

#### 1. Conditional Compilation in Original Code (verilator-fault_simulation)

**Conditional compilation at line 3070**:
```cpp
if (!v3Global.opt.fault_injection()){//fi
    // Generate anonymous structure code (for solving compiler member count bugs)
    // ...
}
```

**Purpose**:
- In fault injection mode, skip anonymous structure generation
- Possibly to avoid conflicts with `fi_object` type declarations
- Or to simplify code generation in fault injection mode

#### 2. Why Is This Conditional Compilation No Longer Needed?

**Reasons**:
1. **Verilator code refactoring**:
   - In `verilator-master`, anonymous structure generation code may have been refactored or removed
   - Code structure has changed, no longer needs this conditional compilation

2. **Header file includes do not affect normal code generation**:
   - The header files we add (`<map>`, `<string>`, `<vector>`, etc.) are all **C++ standard library** files
   - These header files:
     - ✅ Only included when fault injection is enabled (conditional compilation: `if (v3Global.opt.fault_injection())`)
     - ✅ Even if included, they won't affect normal code generation
     - ✅ Only slightly increase compilation time (minimal impact, can be ignored)
     - ✅ Won't produce any side effects or conflicts

3. **Conditional compilation still exists**:
   - Header file includes themselves have conditional compilation protection
   - These header files are only included when fault injection is enabled
   - In normal mode, they are not included, so they don't affect normal code generation

#### 3. Header File Description

**Included header files and their purposes**:
- **`<map>`**: Map structure (though commented out in code, kept for future use)
- **`<string>`**: String operations (for signal names, fault types, etc.)
- **`<fstream>`**: File I/O (possibly for reading fault configuration files)
- **`<sstream>`**: String stream operations (for string conversion)
- **`<vector>`**: For `ffs_keys_t` (signal name list)
- **`<deque>`**: For intermittent fault time arrays (supports efficient `pop_front()` operations)
- **`<cstdlib>`**: Standard library functions (such as `rand()`, etc.)
- **`<ctime>`**: Time-related functions


### Modification 7: fi_object Class Definition (Core Fault Injection Class)

**Corresponding File**: `verilator-master/src/V3EmitCBase.cpp`

**Location in verilator-master**:
- ✅ **Modified**: `V3EmitCModel.cpp` lines 94-400 (approximately), add `fi_object` class definition in `emitHeader()` function
- Location: After class forward declarations, before main class definition
- This is the foundation of the entire fault injection mechanism, all signals of type `fi_object<T>` depend on this class

**Reference Location**: verilator-fault_simulation/src/V3EmitC.cpp lines 3176-3439

**Code Content**:
```cpp
if (v3Global.opt.fault_injection()){ //fi
    // fi_object_base class definition
    // fi_object<T> template class definition
    // operator= overload (fault injection logic)
    // Type conversion operators
    // ...
}
```

**Code Explanation**:

This is the core class definition for fault injection functionality, containing two classes:

#### 1. `fi_object_base` Base Class

**Function**: Provides global control and state management for fault injection

**Main members**:
- **`ffs_keys_t`**: Type alias, `std::vector<std::string>`, stores injectable signal name list
- **`add()` method**: Adds signals to the injectable target list
- **Static member variables** (defined in Modification 5):
  - `ffs_keys`: Signal name list
  - `counter`: Counter
  - `injection_time` / `release_time`: Fault injection/release time
  - `injection_location`: Target signal name
  - `fault_type`: Fault type string
  - `mask` / `bit_vector`: Bit mask related
  - `if_inject_time` / `if_release_time`: Intermittent fault time arrays

#### 2. `fi_object<T>` Template Class

**Function**: Wraps hardware signals, implements fault injection through operator overloading

**Key features**:
- **Constructor**: Receives signal name, initializes value to `T()`
- **`operator=` overload**: Core fault injection logic
  - Checks if current signal is injection target (`m_name == injection_location`)
  - Executes different fault injections according to `fault_type` (sa0, sa1, bit_flip, intermittent_*)
  - Time control: Decides whether to inject based on `VL_TIME_Q()` and `injection_time`/`release_time`
  - Bit vector support: Implements partial bit fault injection through `mask`
- **Type conversion operators**:
  - `operator QData()`: Converts to 64-bit integer
  - `c_str()`: Converts to `unsigned char`
  - `get_value()`: Gets actual value

**For detailed fault injection logic, please refer to the "Fault Type Implementation" section in `Fault_Injection_Mechanism_Explanation.md`.**

