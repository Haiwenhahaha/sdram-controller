// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vtoplevel___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vtoplevel___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vtoplevel___024root__traceDeclTypesSub0(tracep);
}
