#!/bin/sh --login

# ---------------------------------------------------------------------
#
# COPYRIGHT_DATE
# COPYRIGHT_COMPANY
#
# Please review the terms of the license agreement before using this
# file.  If you are not an authorized user, please destroy this source
# file and notify FhG IPMS immediately that you inadvertently 
# received an unauthorized copy.
# ---------------------------------------------------------------------
#
#  Project       : IPCORE_PROJECT
#
#  File          : xm_sim_lin_tb.sh
#  Dependencies  : none
#
#  Model Type:   : executable script
#
#  Description   : Compile script for Cadence Xcelium simulation 
#
#  Designer      : MZ
#
#  QA Engineer   : RH
#
#  Creation Date : 19-Dec-2016
#
#  Version       : IP_CORE_VERSION
# ---------------------------------------------------------------------

. ../../../global_src/LOAD_EDA

# ---------------------------------------------------------------------
# rm -r -f ./xm_sim
# mkdir ./xm_sim
# rm -r -f ./waves.shm
# touch hdl.var
# ---------------------------------------------------------------------



#read sel
echo ' Start testbench...'
which xmsc_run
which xrun
#xmsc_run *.cpp -layout cdebug -top test_drink -scfrontend &

if [ ! -f sdram_dpi_export.h ]; then
  echo "Generating SDRAM DPI headers"
  xrun -f gen_sdram_header.f
    
fi
# Clean up temporary library after header generation
if [ -f sdram_dpi_export.h ] && [ -d tmp_xcelium.d ]; then
  rm -rf tmp_xcelium.d
fi



# Compile Vtoplevel__ALL.cpp with g++ to avoid xmsc crashes
# Check if we need to recompile (if .o doesn't exist or source is newer)
if [ ! -f ../sc-standalone/Vtoplevel__ALL.o ] || [ ../sc-standalone/Vtoplevel__ALL.cpp -nt ../sc-standalone/Vtoplevel__ALL.o ]; then
  echo "Compiling Vtoplevel__ALL.cpp with g++ (to avoid xmsc crashes)..."
  
  # Get CDSROOT from environment - try multiple methods
  if [ -z "$CDSROOT" ]; then
    # Method 1: Try XCELIUMHOME (set by module system)
    if [ -n "$XCELIUMHOME" ]; then
      CDSROOT="$XCELIUMHOME"
      echo "Using CDSROOT from XCELIUMHOME: $CDSROOT"
    # Method 2: Try to get from xrun path
    elif command -v xrun >/dev/null 2>&1; then
      XRUN_PATH=$(command -v xrun)
      # xrun is typically at $CDSROOT/tools/bin/xrun
      CDSROOT=$(dirname $(dirname $(dirname "$XRUN_PATH")))
      if [ -d "$CDSROOT/tools/cdsgcc/gcc/9.3/bin" ]; then
        echo "Using CDSROOT from xrun path: $CDSROOT"
      else
        CDSROOT=""
      fi
    fi
    
    # If still not set, try default location
    if [ -z "$CDSROOT" ]; then
      if [ -d "/sw/CDS/XCELIUM_24_09_004/tools/cdsgcc/gcc/9.3/bin" ]; then
        CDSROOT="/sw/CDS/XCELIUM_24_09_004"
        echo "Using default CDSROOT: $CDSROOT"
      else
        echo "Error: CDSROOT not set and cannot be determined automatically."
        echo "Please set CDSROOT environment variable or ensure XCELIUMHOME is set."
        exit 1
      fi
    fi
  else
    echo "Using CDSROOT from environment: $CDSROOT"
  fi
  
  # Compile Vtoplevel__ALL.cpp with g++ using similar flags as xmsc
  # Note: We use the same g++ that xmsc uses
  GXX="$CDSROOT/tools/cdsgcc/gcc/9.3/bin/g++"
  
  # Compile flags similar to what xmsc uses
  # -fPIC: Position Independent Code (required for shared libraries)
  # -D_GLIBCXX_USE_CXX11_ABI=1: Use C++11 ABI
  # -O0 -g: Debug mode
  # -Wall: Enable warnings
  # -std=c++14: C++14 standard
  # -c: Compile only, don't link
  
  $GXX -std=c++14 \
      -DXMSC \
      -DNCSC \
      -fPIC \
      -D_GLIBCXX_USE_CXX11_ABI=1 \
      -O0 -g \
      -Wall \
      -I../sc-standalone \
      -I../sc-standalone/verilator_include \
      -I"$CDSROOT/tools/systemc/include" \
      -I"$CDSROOT/tools/include" \
      -I"$CDSROOT/tools/inca/include" \
      -c ../sc-standalone/Vtoplevel__ALL.cpp \
      -o ../sc-standalone/Vtoplevel__ALL.o
  
  if [ $? -eq 0 ]; then
    echo "Successfully compiled Vtoplevel__ALL.o"
    ls -lh ../sc-standalone/Vtoplevel__ALL.o
  else
    echo "Error: Failed to compile Vtoplevel__ALL.cpp"
    exit 1
  fi
else
  echo "Vtoplevel__ALL.o is up to date, skipping compilation"
fi



#xrun -f run_sdram.f -gui -access +rwc "$@"


#xrun -f run_sdram.f -R -gui -access +rwc "$@"
#xrun -f run_sdram.f \
#     -gui -access +rwc \
#     -v -messages \
#     -xmscargs "-v" \
#     "$@"

# xrun -f run_sdram.f \
#      -gui -access +rwc \
#      -v 2 -messages \
#      -xmscargs "-v -logfile xmsc.log" \
#      "$@"

#xrun -f run_sdram.f \
#     -gui -access +rwc \
#     -v 2 -messages \
#     -xmscargs "-v" \
#     "$@"

#xrun -xmscargs "-help"
xrun -f run_sdram.f \
     -gui -access +rwc \
     -messages \
     -xmscargs "-messages -verbose -logfile xmsc.log" \
     "$@"
