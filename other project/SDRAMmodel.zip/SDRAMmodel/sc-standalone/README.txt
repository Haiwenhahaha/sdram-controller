cpp1 Packaging Overview
=======================

Mode: standalone
Timestamp: Wed Nov 26 10:32:14 CET 2025

Contents:
---------
- Vtoplevel: Executable
- Vtoplevel*.h: Header files
- Vtoplevel*.cpp: Source files
- Vtoplevel__ALL.a: Static library
- Vtoplevel.mk: Makefile
- Vtoplevel_classes.mk: Class definition Makefile
Note: This bundle does not include the Verilator headers. Install Verilator on the target system.\nSet the VERILATOR_ROOT environment variable to point to the installation directory.\n
Usage:
------
1. Extract the archive
2. Enter the extracted directory
3. Run the executable: ./Vtoplevel
4. Or rebuild: make -f Vtoplevel.mk

Requirements:
-------------
- C++ compiler (GCC/Clang)
- Standard C++ runtime libraries
- Verilator (Must be installed on the system)

