#pragma once

#include <cstdint>
#include <mutex>
#include <queue>

#include "systemc"
#include "svdpi.h"

// Forward declaration to avoid including Vtoplevel.h in header
// This helps avoid xmsc internal assertion failures
class Vtoplevel;

class sdram_model : public sc_core::sc_module {
 public:
  SC_HAS_PROCESS(sdram_model);

  explicit sdram_model(sc_core::sc_module_name name);
  ~sdram_model();

  void dpi_apply_command(std::uint32_t cmd,
                         std::uint64_t addr,
                         std::uint64_t data,
                         std::uint8_t burst_len,
                         bool is_write);

  std::uint64_t dpi_peek(std::uint64_t addr) const;

  // DPI scope management
  void setSvScope(svScope scope) { sv_scope_ = scope; }
  svScope getSvScope() const { return sv_scope_; }

 private:
  struct Command {
    std::uint32_t cmd;
    std::uint64_t addr;
    std::uint64_t data;
    std::uint8_t  burst_len;
    bool          is_write;
  };

  void drive_reset();
  void process_commands();
  bool pop_next_command(Command& cmd);

  // Use raw pointer instead of unique_ptr to avoid needing complete type
  // This helps avoid xmsc internal assertion failures
  // Note: In stub version, this is nullptr and not actually used
  Vtoplevel* dut_;
  sc_core::sc_clock clk_;

  sc_core::sc_signal<bool>        rst_n_;
  sc_core::sc_signal<bool>        btn_n_;
  sc_core::sc_signal<std::uint32_t> gpio0_;
  sc_core::sc_signal<std::uint32_t> gpio1_;
  sc_core::sc_signal<std::uint32_t> sdram_ba_;
  sc_core::sc_signal<bool>        sdram_cs_;
  sc_core::sc_signal<bool>        sdram_ras_;
  sc_core::sc_signal<bool>        sdram_cas_;
  sc_core::sc_signal<bool>        sdram_we_;
  sc_core::sc_signal<std::uint32_t> sdram_dqm_;
  sc_core::sc_signal<bool>        sdram_cke_;
  sc_core::sc_signal<bool>        sdram_clk_;
  sc_core::sc_signal<std::uint32_t> sdram_addr_;
  sc_core::sc_signal<std::uint32_t> sdram_dq_;

  std::queue<Command> pending_cmds_;
  mutable std::mutex  queue_mutex_;
  sc_core::sc_event   cmd_event_;
  
  // SV scope for callbacks
  svScope sv_scope_;
};

// SC_MODULE_EXPORT(sdram_model);

