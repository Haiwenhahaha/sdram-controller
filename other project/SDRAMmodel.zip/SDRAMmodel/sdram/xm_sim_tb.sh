#!/bin/sh --login

# ---------------------------------------------------------------------
#
# COPYRIGHT_DATE
# COPYRIGHT_COMPANY
#
# Please review the terms of the license agreement before using this
# file.  If you are not an authorized user, please destroy this source
# file and notify FhG IPMS immediately that you inadvertently 
# received an unauthorized copy.
# ---------------------------------------------------------------------
#
#  Project       : IPCORE_PROJECT
#
#  File          : xm_sim_lin_tb.sh
#  Dependencies  : none
#
#  Model Type:   : executable script
#
#  Description   : Compile script for Cadence Xcelium simulation 
#
#  Designer      : MZ
#
#  QA Engineer   : RH
#
#  Creation Date : 19-Dec-2016
#
#  Version       : IP_CORE_VERSION
# ---------------------------------------------------------------------

. ../../../global_src/LOAD_EDA

# ---------------------------------------------------------------------
# rm -r -f ./xm_sim
# mkdir ./xm_sim
# rm -r -f ./waves.shm
# touch hdl.var
# ---------------------------------------------------------------------



#read sel
echo ' Start testbench...'
which xmsc_run
which xrun
#xmsc_run *.cpp -layout cdebug -top test_drink -scfrontend &

export CDSROOT=/sw/CDS/XCELIUM_24_09_004   # 或对应版本
#g++ -std=c++14 -DXMSC -DNCSC \
#    -I../sc-standalone -I../sc-standalone/verilator_include \
#    -I"$CDSROOT/tools/systemc/include" \
#    -I"$CDSROOT/tools/include" \
#    -I"$CDSROOT/tools/inca/include" \
#    -c sdram_dpi_bridge.cpp

echo "=== Checking CDSROOT ==="
echo "CDSROOT = $CDSROOT"
echo ""

echo "=== Checking Include Paths ==="
paths=(
    "$CDSROOT/tools/systemc/include"
    "$CDSROOT/tools/include"
    "$CDSROOT/tools/inca/include"
)

for path in "${paths[@]}"; do
    if [ -d "$path" ]; then
        echo "✓ $path"
    else
        echo "✗ $path (NOT FOUND)"
    fi
done

echo "2. chech header file："
key_files=(
    "sdram_model.h"
    "../sc-standalone/Vtoplevel.h"
    "$CDSROOT/tools/include/svdpi.h"
    "$CDSROOT/tools/inca/include/vpi_user.h"
)

for file in "${key_files[@]}"; do
    if [ -f "$file" ]; then
        echo "   ✓ $file"
    else
        echo "   ✗ $file "
    fi
done


g++ -fPIC -DXMSC -DNCSC \
    -I. \
    -I../sc-standalone \
    -I../sc-standalone/verilator_include \
    -I"$CDSROOT/tools/systemc/include" \
    -I"$CDSROOT/tools/include" \
    -I"$CDSROOT/tools/inca/include" \
    -c sdram_model.cpp \
    -o sdram_model.o 2>&1 | tee compile.log