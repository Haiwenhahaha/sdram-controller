#pragma once

#include <cstdint>

class sdram_model;

// Call from the SystemC SDRAM model whenever a response is ready.
void sdram_notify_sv_response(
  sdram_model*    scope,
  std::uint64_t   addr,
  std::uint64_t   data,
  bool            is_write,
  std::uint8_t    burst_len
);

