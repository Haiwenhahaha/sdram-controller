#include "sdram/sdram_dpi_bridge.h"

#include <mutex>
#include <unordered_map>

#include "svdpi.h"
#include "systemc"
#include "vpi_user.h"

#include "sdram/sdram_model.h"

// Forward declaration while sdram_dpi_export.h is not yet generated.
extern "C" void sv_rsp_from_sdram(long long unsigned addr,
                                  long long unsigned data,
                                  svBit              is_write,
                                  unsigned char      burst_len);

namespace {
std::mutex scope_mutex;
std::unordered_map<sdram_model*, svScope> scope_by_model;

svScope find_scope(sdram_model* model) {
  std::lock_guard<std::mutex> lock(scope_mutex);
  auto it = scope_by_model.find(model);
  return it == scope_by_model.end() ? nullptr : it->second;
}

void cache_scope(sdram_model* model, svScope scope) {
  std::lock_guard<std::mutex> lock(scope_mutex);
  scope_by_model[model] = scope;
}
}  // namespace

extern "C" sdram_model* sdram_model__getScopeByName(const char* inst) {
  vpi_printf("DPI PRINT:: sdram_model__getScopeByName called for %s\n", inst);
  sc_core::sc_object* object = sc_core::sc_find_object(inst);
  auto* model = dynamic_cast<sdram_model*>(object);
  if (model == nullptr) {
    vpi_printf("DPI PRINT:: sdram_model__getScopeByName FAILED for %s\n", inst);
  }
  return model;
}

extern "C" void sdram_model__linkSvScope(sdram_model* model) {
  if (model == nullptr) {
    vpi_printf("DPI PRINT:: sdram_model__linkSvScope received null model\n");
    return;
  }
  svScope interface_scope = svGetScope();
  cache_scope(model, interface_scope);
  vpi_printf("DPI PRINT:: sdram_model__linkSvScope cached scope\n");
}

extern "C" void sdram_model__apply_command(sdram_model* model,
                                           unsigned int cmd,
                                           unsigned long long addr,
                                           unsigned long long data,
                                           unsigned char burst_len,
                                           svBit is_write) {
  if (model == nullptr) {
    vpi_printf("DPI PRINT:: sdram_model__apply_command skipped null model\n");
    return;
  }
  model->dpi_apply_command(cmd, addr, data, burst_len, is_write != 0);
}

extern "C" unsigned long long sdram_model__peek_mem(sdram_model* model,
                                                    unsigned long long addr) {
  if (model == nullptr) {
    vpi_printf("DPI PRINT:: sdram_model__peek_mem skipped null model\n");
    return 0ull;
  }
  return model->dpi_peek(addr);
}

void sdram_notify_sv_response(sdram_model* model,
                              std::uint64_t addr,
                              std::uint64_t data,
                              bool is_write,
                              std::uint8_t burst_len) {
  svScope scope = find_scope(model);
  if (scope == nullptr) {
    vpi_printf("DPI PRINT:: sdram_notify_sv_response missing cached scope\n");
    return;
  }
  svSetScope(scope);
  sv_rsp_from_sdram(
    static_cast<long long unsigned>(addr),
    static_cast<long long unsigned>(data),
    static_cast<svBit>(is_write ? 1 : 0),
    static_cast<unsigned char>(burst_len)
  );
}

