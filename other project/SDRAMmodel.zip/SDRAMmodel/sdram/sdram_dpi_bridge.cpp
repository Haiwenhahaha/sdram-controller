#include "svdpi.h"
#include "vpi_user.h"
#include "systemc"

#include "sdram_model.h"
#include "sdram_dpi_bridge.h"

// Suppress warning about string literals in vpi_user.h
#pragma GCC diagnostic ignored "-Wwrite-strings"

// Forward stubs so that the translation unit is independent of SystemC/VPI
//extern "C" void sdram_model__linkSvScope(void*) {}
//extern "C" void sdram_model__apply_command(void*,
//                                           unsigned int,
//                                           unsigned long long,
//                                           unsigned long long,
//                                           unsigned char,
//                                           svBit) {}
//extern "C" unsigned long long sdram_model__peek_mem(void*, unsigned long long) {
//  return 0ULL;
//}
//extern "C" void* sdram_model__getScopeByName(const char*) { return nullptr; }
//extern "C" void sdram_notify_sv_response(void*,
//                                         unsigned long long,
//                                         unsigned long long,
//                                         bool,
//                                         unsigned char) {}
extern "C" {
// Called by SV to get chandle for SystemC instance
void* sdram_model__getScopeByName(const char* inst) {
  vpi_printf("DPI: sdram_model__getScopeByName called with path: %s\n", inst);
  sdram_model* scope = nullptr;
  scope = dynamic_cast<sdram_model*>(sc_core::sc_find_object(inst));
  if (scope == nullptr) {
    vpi_printf("DPI: sdram_model__getScopeByName: instance not found: %s\n", inst);
  } else {
    vpi_printf("DPI: sdram_model__getScopeByName: found instance at %p\n", scope);
  }
  return static_cast<void*>(scope);
}

// Called by SV to link model to calling scope
void sdram_model__linkSvScope(void* in_scope) {
  vpi_printf("DPI: sdram_model__linkSvScope called\n");
  if (in_scope == nullptr) {
    vpi_printf("DPI ERROR: sdram_model__linkSvScope called with null scope\n");
    return;
  }
  sdram_model* scope = static_cast<sdram_model*>(in_scope);
  svScope sv_scope = svGetScope();
  scope->setSvScope(sv_scope);
  vpi_printf("DPI: sdram_model__linkSvScope: linked SV scope to SystemC model\n");
}

// Called by SV to apply a command to the SystemC model
void sdram_model__apply_command(void* in_scope,
                                           unsigned int cmd,
                                           unsigned long long addr,
                                           unsigned long long data,
                                           unsigned char burst_len,
                                           svBit is_write) {
  if (in_scope == nullptr) {
    vpi_printf("DPI ERROR: sdram_model__apply_command called with null scope\n");
    return;
  }
  sdram_model* scope = static_cast<sdram_model*>(in_scope);
  bool is_write_bool = (is_write != 0);
  scope->dpi_apply_command(cmd, addr, data, burst_len, is_write_bool);
}

// Called by SV to peek memory in the SystemC model
unsigned long long sdram_model__peek_mem(void* in_scope,
                                                    unsigned long long addr) {
  if (in_scope == nullptr) {
    vpi_printf("DPI ERROR: sdram_model__peek_mem called with null scope\n");
    return 0ULL;
  }
  sdram_model* scope = static_cast<sdram_model*>(in_scope);
  return scope->dpi_peek(addr);
}

} // extern "C"

// Called from SystemC model to notify SV of a response
void sdram_notify_sv_response(sdram_model* scope,
                              std::uint64_t addr,
                              std::uint64_t data,
                              bool is_write,
                              std::uint8_t burst_len) {
  if (scope == nullptr) {
    vpi_printf("DPI ERROR: sdram_notify_sv_response called with null scope\n");
    return;
  }
  
  svScope sv_scope = scope->getSvScope();
  if (sv_scope == nullptr) {
    vpi_printf("DPI ERROR: sdram_notify_sv_response: SV scope not set\n");
    return;
  }
  
  // Set the scope to the SV interface
  svScope prev_scope = svSetScope(sv_scope);
    
  // Call the exported SV function
  // The function is exported from sdram_model_if.sv as:
  // export "DPI-C" task sv_rsp_from_sdram
  // Note: For tasks, we need to use the correct signature
  // The SV side expects: task sv_rsp_from_sdram(longint unsigned addr, longint unsigned data, bit is_write, byte burst_len)
  // In C++, task becomes void function, and types map as:
  //   longint unsigned -> unsigned long long
  //   bit -> unsigned char (svBit)
  //   byte -> unsigned char
  extern void sv_rsp_from_sdram(unsigned long long addr,
                                 unsigned long long data,
                                 unsigned char is_write,
                                 unsigned char burst_len);
  
  sv_rsp_from_sdram(addr, data, is_write ? 1 : 0, burst_len);
  
  // Restore previous scope
  svSetScope(prev_scope);
  
  vpi_printf("DPI: sdram_notify_sv_response: notified SV with addr=0x%llx data=0x%llx write=%d len=%d\n",
             (unsigned long long)addr, (unsigned long long)data, is_write ? 1 : 0, (int)burst_len);
}