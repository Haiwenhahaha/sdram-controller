

#include "sdram_model.h"
#include "sdram_dpi_bridge.h"

// Include Vtoplevel.h only in .cpp file to avoid xmsc issues in header
// This may still cause xmsc to crash, but we need it for full functionality
#include "Vtoplevel.h"

#include <iostream>
#include <sstream>


using sc_core::SC_NS;
using sc_core::sc_time;

namespace {
const sc_time kClockPeriod = sc_time(10, SC_NS);
const sc_time kResetDuration = sc_time(50, SC_NS);
const sc_time kCmdLatency = sc_time(20, SC_NS);
}

// Constructor: Initialize SystemC module and create Vtoplevel instance
sdram_model::sdram_model(sc_core::sc_module_name name)
    : sc_core::sc_module(name),
      dut_(new Vtoplevel(sc_core::sc_module_name("dut"))),
      clk_("clk", kClockPeriod / 2),
      sv_scope_(nullptr) {
  
  // Connect signals to Vtoplevel
  dut_->sys_clk_pad_i(clk_);
  dut_->rst_n_pad_i(rst_n_);
  dut_->btn_n_pad_i(btn_n_);
  dut_->gpio0_io(gpio0_);
  dut_->gpio1_i(gpio1_);
  dut_->sdram_ba_pad_o(sdram_ba_);
  dut_->sdram_cs_n_pad_o(sdram_cs_);
  dut_->sdram_ras_pad_o(sdram_ras_);
  dut_->sdram_cas_pad_o(sdram_cas_);
  dut_->sdram_we_pad_o(sdram_we_);
  dut_->sdram_dqm_pad_o(sdram_dqm_);
  dut_->sdram_cke_pad_o(sdram_cke_);
  dut_->sdram_clk_pad_o(sdram_clk_);
  dut_->sdram_a_pad_o(sdram_addr_);
  dut_->sdram_dq_pad_io(sdram_dq_);

  // Initialize signals
  rst_n_.write(false);
  btn_n_.write(true);
  gpio0_.write(0);
  gpio1_.write(0);
  sdram_dq_.write(0);

  // Register SystemC threads
  SC_THREAD(drive_reset);
  SC_THREAD(process_commands);

  std::ostringstream msg;
  // msg << "sdram_model constructed: " << name();
  msg << "sdram_model constructed: " << static_cast<const char*>(name);
  SC_REPORT_INFO("SDRAM_MODEL", msg.str().c_str());
}

sdram_model::~sdram_model() {
  if (dut_ != nullptr) {
    delete dut_;
    dut_ = nullptr;
  }
}

// Called from DPI bridge when SV sends a command
void sdram_model::dpi_apply_command(std::uint32_t cmd,
                                    std::uint64_t addr,
                                    std::uint64_t data,
                                    std::uint8_t burst_len,
                                    bool is_write) {
  Command pending{cmd, addr, data, burst_len, is_write};
  {
    std::lock_guard<std::mutex> lock(queue_mutex_);
    pending_cmds_.push(pending);
  }
  
  std::ostringstream msg;
  msg << "Command queued: cmd=" << cmd << " addr=0x" << std::hex << addr
      << " data=0x" << data << " write=" << is_write << " len=" << std::dec << (int)burst_len;
  SC_REPORT_INFO("SDRAM_MODEL", msg.str().c_str());
  
  // Notify the command processing thread
  cmd_event_.notify(sc_core::SC_ZERO_TIME);
}
// Called from DPI bridge when SV wants to peek memory
std::uint64_t sdram_model::dpi_peek(std::uint64_t addr) const {
  // NOTE: This is a placeholder implementation.
  // To fully implement memory peek, you would need to:
  // 1. Access the internal memory state of Vtoplevel (if exposed)
  // 2. Or maintain a shadow memory model that tracks writes
  // 3. Or use Verilator's public_flat access to read internal registers
  //
  // For now, return 0 as a placeholder
  std::ostringstream msg;
  msg << "peek_mem called for addr=0x" << std::hex << addr << " (placeholder: returning 0)";
  SC_REPORT_INFO("SDRAM_MODEL", msg.str().c_str());
  return 0ULL;
}

// SystemC thread: Drive reset signal
void sdram_model::drive_reset() {
  rst_n_.write(false);
  wait(kResetDuration);
  rst_n_.write(true);
  
  std::ostringstream msg;
  msg << "Reset released at time " << sc_core::sc_time_stamp();
  SC_REPORT_INFO("SDRAM_MODEL", msg.str().c_str());
  
  // Keep running (infinite loop)
  while (true) {
    wait(kClockPeriod);
  }
}

// SystemC thread: Process commands from the queue
void sdram_model::process_commands() {
  Command cmd{};
  while (true) {
    wait(cmd_event_);
    
    while (pop_next_command(cmd)) {
      std::ostringstream msg;
      msg << "Processing command: cmd=" << cmd.cmd
          << " addr=0x" << std::hex << cmd.addr
          << " data=0x" << cmd.data
          << " write=" << cmd.is_write
          << " len=" << std::dec << (int)cmd.burst_len;
      SC_REPORT_INFO("SDRAM_MODEL", msg.str().c_str());

      // Wait for command processing latency
      wait(kCmdLatency);

      // NOTE: This is a simplified implementation for DPI connectivity verification.
      // The Vtoplevel model in sc-standalone is a complete SoC with SDRAM controller.
      // To fully drive it, you would need to:
      // 1. Decode the command (ACT/READ/WRITE/PRE/REF/NOP)
      // 2. Drive appropriate signals on dut_ (sdram_ba_, sdram_cs_, sdram_ras_, etc.)
      // 3. Follow SDRAM protocol timing (tRCD, tCAS, tRP, etc.)
      // 4. Handle data transfer for READ/WRITE commands
      // 5. Wait for actual response from the DUT
      //
      // For now, we simulate a successful response by echoing back the command data.
      // This verifies that:
      // - DPI calls from SV → SystemC work
      // - SystemC → SV callbacks work
      // - The integration framework is functional
      
      // Simulate command completion and notify SV
      // In a real implementation, this would be triggered by DUT response
      sdram_notify_sv_response(this, cmd.addr, cmd.data, cmd.is_write, cmd.burst_len);
      
      SC_REPORT_INFO("SDRAM_MODEL", "Command processing completed, response sent to SV");
    }
  }
}

// Helper function: Pop next command from queue
bool sdram_model::pop_next_command(Command& cmd) {
  std::lock_guard<std::mutex> lock(queue_mutex_);
  if (pending_cmds_.empty()) {
    return false;
  }
  cmd = pending_cmds_.front();
  pending_cmds_.pop();
  return true;
}


// Export module for SystemVerilog instantiation
// Must be in .cpp file, not in header, to avoid multiple definition errors
SC_MODULE_EXPORT(sdram_model);