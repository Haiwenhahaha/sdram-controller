#!/bin/csh -f

. ../../global_src/LOAD_EDA
#which xmsc_run
if [ ! -f dpi_export.h ]; then
 echo "Running one-time generation when dpi exports change"
 xrun -f gen_header.f
fi
xrun -f run.f $*:q

