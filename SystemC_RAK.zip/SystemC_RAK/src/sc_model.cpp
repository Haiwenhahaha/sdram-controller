#include "sc_model.h"
#include "vpi_user.h"
// due to bug in vpi header
#pragma GCC diagnostic ignored "-Wwrite-strings" 
#include "svdpi.h"

SC_MODULE_EXPORT(sc_model)


// NOTE: here we simplify the definition of these functions by using the expected C++ type
//    in order to match with the automatically generated dpi_import.h you'd need to use 
//    the lines labelled DPI_IMPORT instead.
//    This does not affect the type safety of these pointers. SV code will need to ensure they are passed
//    correctly in either case.
//    It is recommended that only interface functions call these functions so that pointer to kept safe.

//DPI_IMPORT: #include "dpi_import.h"
extern "C" {


  // Called by SV to get chandle for instance model
  //DPI_IMPORT: void * sc_model__getScopeByName( const char* inst ) {
  sc_model * sc_model__getScopeByName( const char* inst ) {
    vpi_printf("DPI PRINT:: sc_model__getScopeByName called\n");
    sc_model* scope = NULL;
    scope = dynamic_cast<sc_model*>(sc_find_object(inst));
    vpi_printf("DPI PRINT:: sc_model__getScopeByName returning scope of sc_model\n");
    return scope;
  }

  // Called by SV to link model to calling scope
  //DPI_IMPORT: void sc_model__linkSvScope( void * in_scope ) {
  //DPI_IMPORT:   sc_model* scope = (sc_model*)in_scope;
  void sc_model__linkSvScope( sc_model * scope ) {
    vpi_printf("DPI PRINT:: sc_model__linkSvScope called, giving scope of SV interface to SC model \n");
    scope->setScope( svGetScope() );
  }

  // any DPI-C functions that reach into the SystemC should be implemented here //

  //DPI_IMPORT: int sc_model__called_from_sv (void *in_scope, const char* input_string) {
  //DPI_IMPORT:   sc_model* scope = (sc_model*)in_scope;
  int sc_model__called_from_sv (sc_model *scope, const char* input_string) {
    vpi_printf("DPI PRINT:: sc_model__called_from_sv function called from %s\n", input_string);
    // the scope has been set to the right model so calling the function in that model
    return scope->input_string_extern_c(input_string);
  }

}


