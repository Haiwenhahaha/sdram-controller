#include <systemc>
#include <iostream>

#include "dpi_export.h"

//using namespace tlm;
using namespace sc_core;
using namespace sc_dt;
using namespace std;

SC_MODULE( sc_model ) {

#define MEM_SIZE 2000;

  int size;
  int* mem;
  ostringstream msg;

  svScope sv_if;

  SC_CTOR( sc_model ) {
    size         = MEM_SIZE;
    mem          = (int*)malloc( size * sizeof(int) );

    // could have a SC_METHOD here, sensitive to pins that could call
    // back to the Verilog after a certain time
    // SC_METHOD( call_verilog_again );
    //  dont_initialize();
    //  sensitive << clk.pos();
    // The function called by the SC_METHOD (in this case it would be called call_verilog_again)
    // could call the functions that are used in call_verilog() below

    SC_THREAD( initialise_mem );
    SC_THREAD( call_verilog   );

    msg << "System C model constucted  " << name();
    SC_REPORT_INFO( "SYSTEMC:: CONSTRUCTOR:: ", msg.str().c_str() );

  }

  void setScope( svScope _sv_if ) {
    sv_if = _sv_if;
  }

  void call_verilog() {
    ostringstream msg;
    msg << "Entering function call_verilog";
    SC_REPORT_INFO( "SYSTEMC:: ", msg.str().c_str() );

    // waiting to ensure this runs after the Verilog interface and
    // SystemC model have exchanged scopes so they can call each other
    wait(5, SC_NS);

    // call back though the DPI layer to the interface that originally
    // instantiated and called the model.  This could update a memory, toggle
    // a signal or, as in this example trigger an event
    svSetScope(sv_if);
    // call the exported verilog function in the interface with
    // a string for it to print
    sv_called_from_sc_model("string passed from SystemC model");
  }

  int input_string_extern_c(const char* input_string) {
    {
    ostringstream msg;
    msg << "waiting in input_string_extern_c: " << input_string;
    SC_REPORT_INFO( "SYSTEMC:: ", msg.str().c_str() );
    }
    wait(5, SC_NS);
    {
    ostringstream msg;
    msg << "done waiting in input_string_extern_c: " << input_string;
    SC_REPORT_INFO( "SYSTEMC:: ", msg.str().c_str() );
    }
    return 0;
  }

  // create a memory with some values in it like a real model
  void initialise_mem() {
    ostringstream msg;
    int count_initialized_locations;
    for (int ii=0;ii<size;ii++) {
      if ((ii%16) == 0) {
        mem[ii] = 42;
        count_initialized_locations++;
      }
    }
    msg << "Initialized " << count_initialized_locations << " memory_locations";
    SC_REPORT_INFO( "SYSTEMC:: ", msg.str().c_str() );
  }

  // a function to return the memory if requested by the DPI layer
  int* getArray() {
    return mem;
  }

};
